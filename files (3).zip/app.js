const APP_VERSION = "5.11.3";
// BHBL Dice Baseball — v2 (Lineups + Schedule)
const STORAGE_KEY = "bhbl_pwa_v2";

/*** Helpers (robust) ***/
function isSeasonGame(g){
  return !!(g && g.seasonLink && g.seasonLink.scheduleId);
}
// Backwards-compat alias (some builds referenced this by mistake)
function inSeasonGame(g){ return isSeasonGame(g); }

function _initBatLine(){ return {G:0,AB:0,H:0,R:0,RBI:0,HR:0,BB:0,SO:0,SF:0,"2B":0,"3B":0}; }
function _initPitchLine(){ return {GP:0,OUTS:0,H:0,R:0,ER:0,HR:0,BB:0,SO:0,W:0,L:0,SV:0}; }

function num(v){ const n = Number(v); return Number.isFinite(n) ? n : 0; }
function getER(line){ // earned runs fallback for older saves
  if(!line) return 0;
  if(line.ER !== undefined && Number.isFinite(Number(line.ER))) return Number(line.ER);
  // if ER missing/invalid, fall back to total runs (no errors tracked)
  return num(line.R);
}


// Always track per-game boxscore. Season games also mirror stats into season totals.
function gameBat(g, pid){
  g.box = g.box || {batting:{}, pitching:{}};
  g.box.batting = g.box.batting || {};
  if(g.box.batting[pid]==null) g.box.batting[pid]=_initBatLine();
  return g.box.batting[pid];
}
function gamePitch(g, pid){
  g.box = g.box || {batting:{}, pitching:{}};
  g.box.pitching = g.box.pitching || {};
  if(g.box.pitching[pid]==null) g.box.pitching[pid]=_initPitchLine();
  return g.box.pitching[pid];
}
function seasonBat(pid){
  state.season = state.season || {};
  state.season.batting = state.season.batting || {};
  if(state.season.batting[pid]==null) state.season.batting[pid]=_initBatLine();
  return state.season.batting[pid];
}
function seasonPitch(pid){
  state.season = state.season || {};
  state.season.pitching = state.season.pitching || {};
  if(state.season.pitching[pid]==null) state.season.pitching[pid]=_initPitchLine();
  return state.season.pitching[pid];
}

function playoffBat(pid){
  state.season = state.season || {};
  state.season.playoffStats = state.season.playoffStats || {batting:{}, pitching:{}};
  state.season.playoffStats.batting = state.season.playoffStats.batting || {};
  if(state.season.playoffStats.batting[pid]==null) state.season.playoffStats.batting[pid]=_initBatLine();
  return state.season.playoffStats.batting[pid];
}
function playoffPitch(pid){
  state.season = state.season || {};
  state.season.playoffStats = state.season.playoffStats || {batting:{}, pitching:{}};
  state.season.playoffStats.pitching = state.season.playoffStats.pitching || {};
  if(state.season.playoffStats.pitching[pid]==null) state.season.playoffStats.pitching[pid]=_initPitchLine();
  return state.season.playoffStats.pitching[pid];
}

function bump(obj, key, n=1){ obj[key] = (Number(obj[key])||0) + n; }
/*** end helpers ***/


const BA_TIERS = [
  { key:"under_200", label:"Under .200" },
  { key:"200_219", label:".200–.219" },
  { key:"220_239", label:".220–.239" },
  { key:"240_259", label:".240–.259" },
  { key:"260_279", label:".260–.279" },
  { key:"280_299", label:".280–.299" },
  { key:"300_plus", label:".300 & Above" },
];

const CHARTS = {"lt20":{"under_200":{"2":"BB","3":"GO_L","4":"FO_H","5":"FO_1","6":"GO_B1","7":"K","8":"GO_B1","9":"1B1","10":"GO_L","11":"2B2","12":"HR"},"200_219":{"2":"3B","3":"FO_1","4":"FO_1","5":"FO_1","6":"GO_B1","7":"K","8":"GO_B1","9":"1B1","10":"GO_B1","11":"2B3","12":"HR"},"220_239":{"2":"3B","3":"BB","4":"FO_H","5":"FO_H","6":"GO_L","7":"K","8":"FO_H","9":"1B1","10":"GO_L","11":"2B2","12":"HR"},"240_259":{"2":"BB","3":"FO_H","4":"1B2","5":"FO_1","6":"GO_L","7":"K","8":"GO_L","9":"GO_B1","10":"2B3","11":"HR","12":"3B"},"260_279":{"2":"FO_1","3":"GO_B1","4":"HR","5":"FO_1","6":"GO_B1","7":"K","8":"GO_B1","9":"1B2","10":"2B3","11":"GO_B1","12":"FO_1"},"280_299":{"2":"GO_L","3":"BB","4":"GO_L","5":"FO_H","6":"GO_L","7":"K","8":"FO_H","9":"1B2","10":"2B3","11":"HR","12":"3B"},"300_plus":{"2":"BB","3":"GO_L","4":"GO_B1","5":"FO_H","6":"GO_L","7":"K","8":"1B1","9":"FO_1","10":"2B3","11":"HR","12":"3B"}},"ge20":{"under_200":{"2":"GO_B1","3":"GO_B1","4":"FO_1","5":"FO_1","6":"GO_B1","7":"K","8":"GO_B1","9":"1B1","10":"GO_B1","11":"HR","12":"2B3"},"200_219":{"2":"FO_H","3":"BB","4":"FO_H","5":"FO_H","6":"GO_L","7":"K","8":"GO_L","9":"1B1","10":"GO_L","11":"HR","12":"2B3"},"220_239":{"2":"BB","3":"GO_L","4":"FO_H","5":"FO_1","6":"GO_L","7":"K","8":"GO_B1","9":"1B1","10":"HR","11":"FO_1","12":"2B3"},"240_259":{"2":"FO_1","3":"FO_1","4":"FO_1","5":"FO_1","6":"GO_B1","7":"K","8":"2B3","9":"GO_B1","10":"HR","11":"FO_1","12":"1B2"},"260_279":{"2":"FO_H","3":"BB","4":"1B2","5":"FO_H","6":"GO_L","7":"K","8":"GO_L","9":"FO_H","10":"HR","11":"2B3","12":"3B"},"280_299":{"2":"BB","3":"GO_L","4":"GO_L","5":"FO_H","6":"GO_B1","7":"K","8":"GO_B1","9":"1B2","10":"HR","11":"2B3","12":"3B"},"300_plus":{"2":"GO_B1","3":"GO_B1","4":"GO_B1","5":"FO_1","6":"GO_B1","7":"K","8":"1B2","9":"FO_1","10":"HR","11":"2B3","12":"3B"}}};

const el = (id)=>document.getElementById(id);
const uid = ()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36);

function tierLabel(k) { return (BA_TIERS.find(t=>t.key===k)||{label:k}).label; }
function hrLabel(k) { return k==="ge20" ? "20+ HR" : "< 20 HR"; }

/*** Team colors & abbreviations ***/
const TEAM_COLORS = ["#ef4444","#f97316","#f59e0b","#22c55e","#06b6d4","#3b82f6","#6366f1","#a855f7","#ec4899","#84cc16","#14b8a6","#e11d48"];
function makeAbbr(name){
  const words = String(name||"").trim().split(/\s+/).filter(Boolean);
  if(!words.length) return "TM";
  if(words.length===1) return words[0].slice(0,3).toUpperCase();
  return words.map(w=>w[0]).join("").slice(0,3).toUpperCase();
}
function ensureTeamStyle(t, idx=0){
  if(!t) return t;
  if(!t.color) t.color = TEAM_COLORS[idx % TEAM_COLORS.length];
  if(!t.abbr) t.abbr = makeAbbr(t.name);
  return t;
}
function teamDot(t){
  const c = t?.color || "#64748b";
  return `<span class="teamDot" style="background:${c}"></span>`;
}
function getTeamByName(name){
  const k = String(name||"").trim().toLowerCase();
  return state.teams.find(t=>String(t.name||"").trim().toLowerCase()===k) || null;
}

/*** Offseason re-rating: season stats become next season's tier (house rule) ***/
const RERATE_MIN_AB = 1;       // house rule: any AB re-rates; 0 AB keeps last year's ratings
const RERATE_HR_THRESHOLD = 5; // 18-game season house rule: 5+ HR re-rates to the "20+ HR" chart
function avgToTier(avg){
  if(avg>=0.300) return "300_plus";
  if(avg>=0.280) return "280_299";
  if(avg>=0.260) return "260_279";
  if(avg>=0.240) return "240_259";
  if(avg>=0.220) return "220_239";
  if(avg>=0.200) return "200_219";
  return "under_200";
}

function defaultState(){
  const mkTeam=(name)=>({id:uid(),name,roster:[], lineup:[], pitchers:[], defaultSPId:null});
  const home=mkTeam("Home");
  const away=mkTeam("Away");
  for(let i=1;i<=9;i++) {
    home.roster.push({id:uid(),name:`Home Player ${i}`,pos:"NA",tier:"240_259",hr:"lt20"});
    away.roster.push({id:uid(),name:`Away Player ${i}`,pos:"NA",tier:"240_259",hr:"lt20"});
  }
  home.lineup = home.roster.slice(0,9).map(p=>p.id);
  away.lineup = away.roster.slice(0,9).map(p=>p.id);

  const divs=[
    {id:uid(), name:"East"},
    {id:uid(), name:"West"},
    {id:uid(), name:"North"},
    {id:uid(), name:"South"},
  ];
  home.divisionId = divs[0].id;
  away.divisionId = divs[1].id;

  return { teams:[home,away], schedule:[],
  gameHistory:[],
  franchise:{ seasonNumber:1, history:[] },
  ticker:{ queue:[], last:{HR:null} },
  season:{ batting:{}, pitching:{}, standings:{}, gameLog:[], structure:{ leagueName:"League", divisions:divs }, playoffs:null, playoffStats:{ batting:{}, pitching:{} } } };
}

function loadState(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return defaultState();
    const s = JSON.parse(raw);
    if(!s.teams) return defaultState();
    let _ci = 0;
    for(const t of s.teams){
      ensureTeamStyle(t, _ci++);
      if(!t.roster) t.roster=[];
      if(!t.lineup) t.lineup = t.roster.slice(0,9).map(p=>p.id);
      if(!t.pitchers) t.pitchers=[];
      if(t.defaultSPId===undefined) t.defaultSPId=null;
      if(t.divisionId===undefined) t.divisionId=null;
    }
    if(!s.schedule) s.schedule=[];
    // v5 schedule migration: assign game numbers
    let maxNo=0;
    for(const g of s.schedule){
      if(g.gameNo) maxNo=Math.max(maxNo, Number(g.gameNo)||0);
    }
    for(const g of s.schedule){
      if(!g.gameNo){ maxNo += 1; g.gameNo = maxNo; }
      if(g.status===undefined) g.status="scheduled";
      if(g.awayScore===undefined) g.awayScore=0;
      if(g.homeScore===undefined) g.homeScore=0;
      if(g.playedAt===undefined) g.playedAt=null;
    }
    if(!s.season) s.season={batting:{}, pitching:{}, standings:{}, gameLog:[], structure:null, playoffs:null, playoffStats:{batting:{}, pitching:{}}};
    if(!s.season.batting) s.season.batting={};
    if(!s.season.pitching) s.season.pitching={};
    if(!s.season.standings) s.season.standings={};
    if(!s.season.gameLog) s.season.gameLog=[];
    if(!s.season.structure) s.season.structure = { leagueName:"League", divisions:[] };
    if(!Array.isArray(s.season.structure.divisions)) s.season.structure.divisions=[];

    // Division migration: ensure at least 4 divisions exist, and assign teams if missing
    if(s.season.structure.divisions.length===0){
      s.season.structure.divisions = [
        {id:uid(), name:"East"},
        {id:uid(), name:"West"},
        {id:uid(), name:"North"},
        {id:uid(), name:"South"},
      ];
    }
    const divIds = s.season.structure.divisions.map(d=>d.id);
    let di=0;
    for(const t of s.teams){
      if(!t.divisionId || !divIds.includes(t.divisionId)){
        t.divisionId = divIds[di % divIds.length];
        di++;
      }
    }
    for(const k of Object.keys(s.season.pitching)){
      const ps=s.season.pitching[k];
      if(ps.GP===undefined) ps.GP = (ps.G!==undefined) ? ps.G : 0; // back-compat
      if(ps.ER===undefined && ps.R!==undefined) ps.ER = ps.R; // backfill: older saves tracked only R
      if(ps.W===undefined) ps.W=0;
      if(ps.L===undefined) ps.L=0;
      if(ps.SV===undefined) ps.SV=0;
    }

    // Boxscore migration (older games may not have ER tracked in per-game pitching lines)
    const patchGameBox = (g)=>{
      if(!g || !g.box || !g.box.pitching) return;
      for(const pid of Object.keys(g.box.pitching)){
        const ps = g.box.pitching[pid];
        if(!ps) continue;
        if(ps.ER===undefined && ps.R!==undefined) ps.ER = ps.R;
        if(ps.GP===undefined && ps.G!==undefined) ps.GP = ps.G;
        // ensure required keys exist so tables never show blank/undefined
        if(ps.OUTS===undefined) ps.OUTS = 0;
        if(ps.H===undefined) ps.H = 0;
        if(ps.R===undefined) ps.R = 0;
        if(ps.ER===undefined) ps.ER = 0;
        if(ps.HR===undefined) ps.HR = 0;
        if(ps.BB===undefined) ps.BB = 0;
        if(ps.SO===undefined) ps.SO = 0;
        if(ps.W===undefined) ps.W = 0;
        if(ps.L===undefined) ps.L = 0;
        if(ps.SV===undefined) ps.SV = 0;
      }
    };
    for(const g of (s.schedule||[])) patchGameBox(g);
    for(const g of (s.season.gameLog||[])) patchGameBox(g);

    // SF backfill (older saves didn't track sacrifice flies)
    for(const k of Object.keys(s.season.batting)){
      if(s.season.batting[k].SF===undefined) s.season.batting[k].SF = 0;
    }

    // Franchise migration (multi-season history)
    if(!s.franchise) s.franchise = { seasonNumber:1, history:[] };
    if(!Array.isArray(s.franchise.history)) s.franchise.history = [];
    if(!s.franchise.seasonNumber) s.franchise.seasonNumber = 1;

    // Playoffs migration
    if(s.season.playoffs===undefined) s.season.playoffs = null;
    if(!s.season.playoffStats) s.season.playoffStats = { batting:{}, pitching:{} };
    if(!s.season.playoffStats.batting) s.season.playoffStats.batting = {};
    if(!s.season.playoffStats.pitching) s.season.playoffStats.pitching = {};
    return s;
  } catch { return defaultState(); }
}
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }

let state = loadState();
  if(el("tickerClose")) el("tickerClose").onclick=()=>{ state.ticker.queue=[]; saveState(); renderTicker(); };


function getTeam(id){ return state.teams.find(t=>t.id===id); }
function getPlayer(pid){
  for(const t of state.teams){
    const p=t.roster.find(x=>x.id===pid);
    if(p) return p;
  }
  return null;
}

function ensurePitch(pid){
  if(!pid) return;
  if(!state.season.pitching[pid]) state.season.pitching[pid] = _initPitchLine();
}
function outsToIP(outs){
  const full = Math.floor(outs/3);
  const rem = outs % 3;
  return `${full}.${rem}`;
}
function getPitcher(teamId, pid){
  const t=getTeam(teamId);
  return t?.pitchers?.find(p=>p.id===pid) || null;
}
function fillPitcherSelect(sel, teamId){
  sel.innerHTML="";
  const t=getTeam(teamId);
  const list=t?.pitchers||[];
  const none=document.createElement("option");
  none.value=""; none.textContent="(none)";
  sel.appendChild(none);
  for(const p of list){
    const o=document.createElement("option");
    o.value=p.id; o.textContent=`${p.name} (${p.role})`;
    sel.appendChild(o);
  }
}
function defensiveSide(g){
  return battingSide(g)==="away" ? "home" : "away";
}
function currentPitcherId(g){
  const def = defensiveSide(g);
  return g?.pitcher?.[def] || "";
}

function ensureBat(pid){
  if(!state.season.batting[pid]) state.season.batting[pid] = _initBatLine();
}

function ensureGameBat(pid){
  if(!game || !pid) return;
  if(!game.box) game.box={batting:{}, pitching:{}};
  if(!game.box.batting[pid]) game.box.batting[pid] = _initBatLine();
}
function ensureGamePitch(pid){
  if(!game || !pid) return;
  if(!game.box) game.box={batting:{}, pitching:{}};
  if(!game.box.pitching[pid]) game.box.pitching[pid] = _initPitchLine();
}



function notePitcherEntry(teamSide, pid){
  if(!game || !pid) return;
  if(!game.decision) game.decision = { runEvents:[], pitcherEntries:{}, pitchOuts:{}, finalDecisions:null };
  if(!game.decision.pitcherEntries[pid]){
    game.decision.pitcherEntries[pid] = {
      teamSide,
      scoreHome: game.score.home,
      scoreAway: game.score.away,
      inning: game.inning,
      half: game.half
    };
  }
}

function recordRunEvent(){
  if(!game || !game.decision) return;
  game.decision.runEvents.push({
    inning: game.inning,
    half: game.half,
    scoreHome: game.score.home,
    scoreAway: game.score.away,
    homePitcher: game.pitcher?.home || "",
    awayPitcher: game.pitcher?.away || ""
  });
}

function computePitcherDecisions(g){
  const homeRuns = g.score.home;
  const awayRuns = g.score.away;
  if(homeRuns===awayRuns){
    return { winner:null, winPid:"", lossPid:"", savePid:"" };
  }
  const winner = homeRuns>awayRuns ? "home" : "away";
  const loser  = winner==="home" ? "away" : "home";

  const events = g.decision?.runEvents || [];
  let lastGoAheadIdx = -1;

  let prevHome=0, prevAway=0;
  for(let i=0;i<events.length;i++){
    const ev = events[i];
    const prevLead = prevHome - prevAway;
    const newLead = ev.scoreHome - ev.scoreAway;
    const winnerLeadBefore = (winner==="home"? prevLead : -prevLead);
    const winnerLeadAfter  = (winner==="home"? newLead  : -newLead);
    if(winnerLeadBefore<=0 && winnerLeadAfter>0){
      lastGoAheadIdx = i;
    }
    prevHome = ev.scoreHome; prevAway = ev.scoreAway;
  }

  // verify "for good"
  if(lastGoAheadIdx>=0){
    for(let i=lastGoAheadIdx+1;i<events.length;i++){
      const diff = events[i].scoreHome - events[i].scoreAway;
      const winnerLead = (winner==="home"? diff : -diff);
      if(winnerLead<=0){ lastGoAheadIdx=-1; break; }
    }
  }

  // fallback: first moment winner leads
  if(lastGoAheadIdx<0){
    for(let i=0;i<events.length;i++){
      const diff = events[i].scoreHome - events[i].scoreAway;
      const winnerLead = (winner==="home"? diff : -diff);
      if(winnerLead>0){ lastGoAheadIdx=i; break; }
    }
  }

  let winPid="", lossPid="";
  if(lastGoAheadIdx>=0){
    const ev = events[lastGoAheadIdx];
    winPid  = (winner==="home") ? (ev.homePitcher||"") : (ev.awayPitcher||"");
    lossPid = (loser==="home")  ? (ev.homePitcher||"") : (ev.awayPitcher||"");
  }

  const finalPid = (winner==="home") ? (g.pitcher?.home||"") : (g.pitcher?.away||"");
  let savePid = "";
  if(finalPid && finalPid!==winPid){
    const entry = g.decision?.pitcherEntries?.[finalPid] || null;
    const outs = Number(g.decision?.pitchOuts?.[finalPid] || 0);
    const leadAtEntry = entry ? ((winner==="home") ? (entry.scoreHome - entry.scoreAway) : (entry.scoreAway - entry.scoreHome)) : 999;
    if(leadAtEntry<=4 || outs>=9){
      savePid = finalPid;
    }
  }

  return { winner, winPid, lossPid, savePid };
}

function applyPitcherDecisionsToSeason(dec){
  if(!dec || !dec.winner) return;
  if(dec.winPid){ ensurePitch(dec.winPid); state.season.pitching[dec.winPid].W += 1; }
  if(dec.lossPid){ ensurePitch(dec.lossPid); state.season.pitching[dec.lossPid].L += 1; }
  if(dec.savePid){ ensurePitch(dec.savePid); state.season.pitching[dec.savePid].SV += 1; }
}


function fillTeamSelect(sel){
  sel.innerHTML="";
  for(const t of state.teams){
    const o=document.createElement("option");
    o.value=t.id; o.textContent=t.name;
    sel.appendChild(o);
  }
}
function fillTierSelect(sel){
  sel.innerHTML="";
  for(const t of BA_TIERS){
    const o=document.createElement("option");
    o.value=t.key; o.textContent=t.label;
    sel.appendChild(o);
  }
  sel.value="240_259";
}

function roll2d6(){
  const d1=1+Math.floor(Math.random()*6);
  const d2=1+Math.floor(Math.random()*6);
  return {d1,d2,total:d1+d2};
}

// -------- Lineups --------
function normalizedLineup(team){
  const rosterIds = team.roster.map(p=>p.id);
  const uniq = (arr)=>arr.filter((x,i)=>arr.indexOf(x)===i);
  let line = uniq((team.lineup||[]).filter(id=>rosterIds.includes(id)));
  for(const rid of rosterIds){
    if(line.length>=9) break;
    if(!line.includes(rid)) line.push(rid);
  }
  while(line.length<9 && rosterIds.length) line.push(rosterIds[line.length % rosterIds.length]);
  return line.slice(0,9);
}
function setTeamLineup(team, lineup9, bench){
  const rosterIds = team.roster.map(p=>p.id);
  const clean = (arr)=>arr.filter(id=>rosterIds.includes(id));
  const combined = [...clean(lineup9), ...clean(bench)];
  const seen=new Set();
  team.lineup = combined.filter(id=>{ if(seen.has(id)) return false; seen.add(id); return true; }).slice(0, Math.max(9, rosterIds.length));
}

// DnD helper
function makeDndList(listEl){
  let dragEl=null;
  function onDragStart(e){
    dragEl = e.currentTarget;
    dragEl.classList.add("dragging");
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", dragEl.dataset.pid);
  }
  function onDragEnd(){
    if(dragEl) dragEl.classList.remove("dragging");
    dragEl=null;
  }
  function onDragOver(e){
    e.preventDefault();
    const after = getDragAfterElement(listEl, e.clientY);
    const dragging = document.querySelector(".dragging");
    if(!dragging) return;
    if(after == null) listEl.appendChild(dragging);
    else listEl.insertBefore(dragging, after);
  }
  listEl.addEventListener("dragover", onDragOver);
  listEl.addEventListener("drop", (e)=>{
    e.preventDefault();
    const pid = e.dataTransfer.getData("text/plain");
    const items = [...listEl.querySelectorAll("li")];
    const idx = items.findIndex(x=>x.classList.contains("dragging"));
    // fire callback after DOM order changed
    if(listEl._onReorder) listEl._onReorder(pid, idx);
  });
  listEl._attachItem = (li)=>{
    li.draggable=true;
    li.addEventListener("dragstart", onDragStart);
    li.addEventListener("dragend", onDragEnd);
    li.addEventListener("click", ()=>{ if(listEl._onClickItem) listEl._onClickItem(li); });
  };
}
function getDragAfterElement(container, y){
  const els = [...container.querySelectorAll("li:not(.dragging)")];
  return els.reduce((closest, child)=>{
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height/2;
    if(offset < 0 && offset > closest.offset) return { offset, element: child };
    return closest;
  }, { offset: Number.NEGATIVE_INFINITY, element: null }).element;
}
function collectListIds(listEl){ return [...listEl.querySelectorAll("li")].map(li=>li.dataset.pid); }

function renderLineupEditor(){
  const team = getTeam(el("lineupTeam").value);
  const lineupList = el("lineupList");
  const benchList = el("benchList");
  lineupList.innerHTML=""; benchList.innerHTML="";
  if(!team) return;

  const lineup9 = normalizedLineup(team);
  const lineupSet = new Set(lineup9);
  const bench = team.roster.map(p=>p.id).filter(id=>!lineupSet.has(id));

  function mkItem(pid, idx){
    const p = getPlayer(pid);
    const li = document.createElement("li");
    li.dataset.pid = pid;
    li.innerHTML = `<span>${idx!=null? (idx+1)+". " : ""}<b>${p?.name ?? "?"}</b> <span class="small">(${p?.pos ?? "NA"})</span></span>
                    <span class="badge">${tierLabel(p?.tier ?? "")} · ${hrLabel(p?.hr ?? "lt20")}</span>`;
    return li;
  }
  lineup9.forEach((pid,i)=>{ const li=mkItem(pid,i); lineupList.appendChild(li); lineupList._attachItem(li); });
  bench.forEach((pid)=>{ const li=mkItem(pid,null); benchList.appendChild(li); benchList._attachItem(li); });
}

// -------- Schedule --------
let selectedGameId = null;
let scheduleDivFilter = "all";

function fillScheduleDivFilter(){
  const sel = el("schedDivFilter");
  if(!sel) return;
  ensureDivisions();
  sel.innerHTML = "";
  const all=document.createElement("option");
  all.value = "all"; all.textContent = "All";
  sel.appendChild(all);
  for(const d of state.season.structure.divisions){
    const o=document.createElement("option");
    o.value = d.id;
    o.textContent = d.name;
    sel.appendChild(o);
  }
  sel.value = scheduleDivFilter;
  sel.onchange = ()=>{ scheduleDivFilter = sel.value; renderSchedule(); };
}
function renderSchedule(){
  const list = el("scheduleList");
  list.innerHTML="";
  fillGenDivisionSelect();
  fillScheduleDivFilter();
  const sched = state.schedule.slice().sort((a,b)=>(Number(a.gameNo||0)-Number(b.gameNo||0)));
  if(!sched.length){
    list.innerHTML = `<div class="hint" style="padding:10px">No games scheduled.</div>`;
    selectedGameId=null;
    return;
  }

  const filtered = (scheduleDivFilter==="all") ? sched : sched.filter(g=>{
    const a=getTeam(g.awayId); const h=getTeam(g.homeId);
    return (a?.divisionId===scheduleDivFilter) || (h?.divisionId===scheduleDivFilter);
  });

  if(!filtered.length){
    list.innerHTML = `<div class="hint" style="padding:10px">No games for this division.</div>`;
    return;
  }

  for(const g of filtered){
    const awayT = getTeam(g.awayId), homeT = getTeam(g.homeId);
    const away = awayT ? `${teamDot(ensureTeamStyle(awayT))}${awayT.name}` : "??";
    const home = homeT ? `${teamDot(ensureTeamStyle(homeT))}${homeT.name}` : "??";
    const row = document.createElement("div");
    row.className = "schedRow" + (g.id===selectedGameId ? " selected" : "");
    const inn = (g.innings && Number(g.innings)>9) ? ` (${g.innings})` : "";
    const status = g.status==="final" ? `<span class="final">Final</span> ${g.awayScore}-${g.homeScore}${inn}` : `<span class="meta">Scheduled</span>`;
    row.innerHTML = `<div>Game ${g.gameNo ?? ""}</div><div><b>${away}</b></div><div><b>${home}</b></div><div>${status}</div>`;
    row.onclick = ()=>{ selectedGameId = g.id; renderSchedule();
    renderStandings(); };
    list.appendChild(row);
  }
}

function nextGameNo(){
  let maxNo=0;
  for(const g of state.schedule){
    maxNo = Math.max(maxNo, Number(g.gameNo||0));
  }
  return maxNo + 1;
}
function addScheduledGame(awayId, homeId){
  state.schedule.push({
    id: uid(),
    gameNo: nextGameNo(),
    awayId,
    homeId,
    status:"scheduled",
    awayScore:0,
    homeScore:0,
    playedAt:null
  });
  saveState();
}


function rrPairings(teamIds){
  // Circle method. Returns rounds: array of pairs [homeId, awayId].
  const ids = teamIds.slice();
  if(ids.length % 2 === 1) ids.push(null); // bye
  const n = ids.length;
  const rounds = n - 1;
  const half = n / 2;
  const arr = ids.slice();
  const out = [];

  for(let r=0;r<rounds;r++){
    const pairs=[];
    for(let i=0;i<half;i++){
      const a = arr[i];
      const b = arr[n-1-i];
      if(a!==null && b!==null){
        // alternate by round for some balance
        const home = (r % 2 === 0) ? a : b;
        const away = (r % 2 === 0) ? b : a;
        pairs.push([home, away]);
      }
    }
    out.push(pairs);
    // rotate (keep first fixed)
    const fixed = arr[0];
    const rest = arr.slice(1);
    rest.unshift(rest.pop());
    arr.splice(0, arr.length, fixed, ...rest);
  }
  return out;
}

function fillGenDivisionSelect(){
  const sel = el("genDivision");
  if(!sel) return;
  ensureDivisions();
  sel.innerHTML = "";
  for(const d of state.season.structure.divisions){
    const o=document.createElement("option");
    o.value=d.id;
    o.textContent=d.name;
    sel.appendChild(o);
  }
  // Default to first division if not set
  if(!sel.value && state.season.structure.divisions[0]) sel.value = state.season.structure.divisions[0].id;
 }

function generateSchedule(){
  const mode = el("genMode")?.value || "replace";
  const divId = el("genDivision")?.value || "";
  const gamesPerOpp = Number(el("genGPO")?.value || 6);
  ensureDivisions();
  const div = state.season.structure.divisions.find(d=>d.id===divId) || state.season.structure.divisions[0];
  if(!div) return alert("Create divisions first.");
  const divTeamIds = state.teams.filter(t=>t.divisionId===div.id).map(t=>t.id);
  if(divTeamIds.length < 2) return alert("This division needs at least 2 teams.");

  if(mode==="replace"){
    const hasAny = state.schedule.some(g=>{
      const a=getTeam(g.awayId); const h=getTeam(g.homeId);
      const inDiv = (a?.divisionId===div.id) && (h?.divisionId===div.id);
      return inDiv && g.status!=="final";
    });
    if(hasAny && !confirm("Replace this division’s unplayed games?")) return;
    // Only remove UNPLAYED games where both teams are in this division.
    state.schedule = state.schedule.filter(g=>{
      const a=getTeam(g.awayId); const h=getTeam(g.homeId);
      const inDiv = (a?.divisionId===div.id) && (h?.divisionId===div.id);
      return !(inDiv && g.status!=="final");
    });
  }
  if(mode==="append"){
    if(state.schedule.length>0 && !confirm("Append games for this division?")) return;
  }

  let gameNo = 1;
  for(const g of state.schedule){
    gameNo = Math.max(gameNo, Number(g.gameNo||0)+1);
  }

  // Standalone division schedule: teams ONLY play teams in their division.
  // IMPORTANT UX: don't stack all games vs the same opponent back-to-back.
  // We generate a round-robin "cycle" (circle method), then repeat that cycle
  // `gamesPerOpp` times. For 4 teams, each cycle is 3 rounds (2 games/round).
  // Repeating the cycle 6x yields 6 meetings vs each opponent (18 games/team),
  // and naturally rotates opponents so you don't play the same team 6 straight.
  const ids = divTeamIds.slice();
  const baseRounds = rrPairings(ids);
  for(let rep=0; rep<gamesPerOpp; rep++){
    for(const round of baseRounds){
      for(const pair of round){
        let homeId = pair[0];
        let awayId = pair[1];
        // Flip home/away each repetition for balance.
        if(rep % 2 === 1){
          const tmp = homeId; homeId = awayId; awayId = tmp;
        }
        state.schedule.push({
          id: uid(),
          gameNo: gameNo++,
          awayId,
          homeId,
          status:"scheduled",
          awayScore:0,
          homeScore:0,
          playedAt:null
        });
      }
    }
  }

  saveState();
  renderSchedule();
  renderStandings();
}

function clearScheduleAll(){
  if(state.schedule.length===0) return;
  if(!confirm("Clear the entire schedule?")) return;
  state.schedule = [];
  selectedGameId = null;
  saveState();
  renderSchedule();
  renderStandings();
}


// -------- Game Engine --------
let game = null;
let simFast = false;

function buildGameLineup(team){ return normalizedLineup(team); }

function newGame(homeId, awayId){
  const home=getTeam(homeId), away=getTeam(awayId);
  return {
    homeId, awayId,
    inning:1, half:"top", outs:0,
    bases:[null,null,null],
    score:{home:0,away:0},
    idx:{home:0,away:0},
    lineup:{home:buildGameLineup(home), away:buildGameLineup(away)},
    pitcher:{home:"", away:""},
    seasonLink:null,
    decision:{ runEvents:[], pitcherEntries:{}, pitchOuts:{}, finalDecisions:null },
    final:false,
    log:[],
    box:{ batting:{}, pitching:{} }
  };
}
function battingSide(g){ return g.half==="top" ? "away" : "home"; }


function updateScoreboardUI(){
  const sb = el("scoreboardSticky");
  if(!sb) return;
  if(!game){
    el("sbAwayName").textContent="Away";
    el("sbHomeName").textContent="Home";
    el("sbAwayScore").textContent="0";
    el("sbHomeScore").textContent="0";
    el("sbInning").textContent="";
    el("sbOuts").textContent="";
    el("sbNote").textContent="";
    ["d1","d2","d3"].forEach(id=>el(id)?.classList.remove("occ"));
    el("sbAway")?.classList.remove("active");
    el("sbHome")?.classList.remove("active");
    return;
  }
  const awayT=getTeam(game.awayId);
  const homeT=getTeam(game.homeId);
  ensureTeamStyle(awayT); ensureTeamStyle(homeT);
  el("sbAwayName").innerHTML = awayT ? `${teamDot(awayT)}${awayT.abbr||awayT.name}` : "Away";
  el("sbHomeName").innerHTML = homeT ? `${teamDot(homeT)}${homeT.abbr||homeT.name}` : "Home";
  if(awayT) el("sbAwayName").title = awayT.name;
  if(homeT) el("sbHomeName").title = homeT.name;
  el("sbAwayScore").textContent = String(game.score.away);
  el("sbHomeScore").textContent = String(game.score.home);

  const inn = `${game.half.toUpperCase()} ${game.inning}`;
  el("sbInning").textContent = game.final ? "FINAL" : inn;
  const outs = game.outs;
  el("sbOuts").textContent = `${outs} out${outs===1?"":"s"}`;

  const batting = battingSide(game);
  el("sbHome").classList.toggle("active", batting==="home" && !game.final);
  el("sbAway").classList.toggle("active", batting==="away" && !game.final);

  el("d1")?.classList.toggle("occ", !!game.bases?.[0]);
  el("d2")?.classList.toggle("occ", !!game.bases?.[1]);
  el("d3")?.classList.toggle("occ", !!game.bases?.[2]);
const hp = getPitcher(game.homeId, game.pitcher?.home)?.name;
  const ap = getPitcher(game.awayId, game.pitcher?.away)?.name;
  el("sbNote").textContent = (hp||ap) ? `P: ${ap||"?"} / ${hp||"?"}` : "";
}

function triggerPlayFX(code){
  if(simFast) return;
  if(!code) return;
  const sb = el("scoreboardSticky");
  if(!sb) return;
  sb.classList.remove("playFX-good","playFX-hr","playFX-bad");
  void sb.offsetWidth;
  const good = ["1B","2B","3B","BB","HBP"].includes(code);
  const hr = code==="HR";
  const bad = ["K","GO","FO","PO","LO","DP"].includes(code);
  if(hr) sb.classList.add("playFX-hr");
  else if(good) sb.classList.add("playFX-good");
  else if(bad) sb.classList.add("playFX-bad");
}

function batterId(g){
  const side = battingSide(g);
  const arr = g.lineup[side];
  return arr[g.idx[side] % arr.length];
}


function isGameOver(g){
  // End rules:
  // 1) After TOP of 9+ : if home team is leading, game ends (no need to play bottom).
  if(g.inning >= 9 && g.half==="top" && g.score.home > g.score.away) return true;

  // 2) After BOTTOM of 9+ : if score is not tied, game ends.
  // In our engine, we evaluate this right when a bottom half ends.
  if(g.inning >= 9 && g.half==="bottom" && g.score.home !== g.score.away) return true;

  return false;
}

function checkWalkoff(g){
  // Home team takes the lead in the bottom of the 9th or later: game ends immediately.
  if(!g || g.final) return false;
  if(g.half==="bottom" && g.inning>=9 && g.score.home > g.score.away){
    g.final = true;
    addLog(g, `WALK-OFF! Final: ${g.score.away}–${g.score.home}`);
    return true;
  }
  return false;
}

function nextBatter(g){
  const side = battingSide(g);
  g.idx[side] = (g.idx[side] + 1) % g.lineup[side].length;
}
function addLog(g,msg){
  const stamp = `${g.inning}${g.half==="top"?"▲":"▼"} (${g.outs} out)`;
  g.log.unshift(`[${stamp}] ${msg}`);
  if(g.log.length>250) g.log.length=250;
}
function endHalf(g){
  // reset inning state
  g.outs=0; g.bases=[null,null,null];

  if(g.half==="top"){
    // finished top half -> go to bottom (same inning)
    // If it's 9th+ and home is already leading, skip bottom and end.
    if(g.inning>=9 && g.score.home > g.score.away){
      g.final = true;
      addLog(g, `Final: ${g.score.away}–${g.score.home}`);
      return;
    }
    g.half="bottom";
    return;
  }

  // finished bottom half -> inning complete
  if(g.inning>=9 && g.score.home !== g.score.away){
    g.final = true;
    addLog(g, `Final: ${g.score.away}–${g.score.home}`);
    return;
  }

  g.half="top";
  g.inning += 1;
}


function creditRun(pid){
  if(!pid || !game) return;
  bump(gameBat(game, pid), "R", 1);
  if(isSeasonGame(game)) bump(seasonBat(pid), "R", 1);
}
function rbi(bid){
  if(!bid || !game) return;
  bump(gameBat(game, bid), "RBI", 1);
  if(isSeasonGame(game)) bump(seasonBat(bid), "RBI", 1);
}
function scoreRun(g, bid){
  // Rule (simplified): if the 3rd out is made on this play, no runs score.
  if(g && g._outsBeforePlay===2 && g.outs>=3) return;
  const side = battingSide(g);
  g.score[side] += 1;
  recordRunEvent();
  // pitching: charge run to active pitcher (fielding team)
  const rpid = currentPitcherId(g);
  if(rpid){
    bump(gamePitch(g, rpid), "R", 1);
    bump(gamePitch(g, rpid), "ER", 1); // simplified: all runs are earned (no errors tracked)
    if(isSeasonGame(g)){
      bump(seasonPitch(rpid), "R", 1);
      bump(seasonPitch(rpid), "ER", 1);
    }
  }
  if(bid) rbi(bid);
}

function walkAdvance(g, bid){
  const b=g.bases.slice();
  if(!b[0]){ g.bases[0]=bid; return; }
  if(!b[1]){ g.bases[1]=b[0]; g.bases[0]=bid; return; }
  if(!b[2]){ g.bases[2]=b[1]; g.bases[1]=b[0]; g.bases[0]=bid; return; }
  creditRun(b[2]); scoreRun(g,bid);
  g.bases[2]=b[1]; g.bases[1]=b[0]; g.bases[0]=bid;
}
function advanceAll(g, n, bid, batterBaseIndex){
  const old=g.bases.slice();
  const nb=[null,null,null];
  // 3rd-out rule: if the 3rd out was made on this play, no runs (or R credit) count
  const runsCount = !(g._outsBeforePlay===2 && g.outs>=3);
  for(let i=2;i>=0;i--){
    const r=old[i];
    if(!r) continue;
    const to=i+n;
    if(to>=3){ if(runsCount){ creditRun(r); scoreRun(g,bid); } }
    else nb[to]=r;
  }
  if(batterBaseIndex>=0) nb[batterBaseIndex]=bid;
  g.bases=nb;
}
function fcLeadOut(g, bid){
  const b=g.bases.slice();
  const lead = b[2]?2:(b[1]?1:(b[0]?0:-1));
  if(lead===-1){ g.outs+=1; return "batter out"; }
  b[lead]=null;
  g.outs+=1;
  const nb=[null,null,null];
  if(lead===2){ if(b[1]) nb[2]=b[1]; if(b[0]) nb[1]=b[0]; }
  else if(lead===1){ if(b[2]) nb[2]=b[2]; if(b[0]) nb[1]=b[0]; }
  else { if(b[2]) nb[2]=b[2]; if(b[1]) nb[1]=b[1]; }
  nb[0]=bid;
  g.bases=nb;
  return "FC lead out";
}

function apply(code, roll){
  const g=game;
  const bid=batterId(game);
  const batter=getPlayer(bid);
  // snapshot outs at start of play (for 3rd-out run rule)
  g._outsBeforePlay = g.outs;
  const s = gameBat(g, bid);
  const ss = isSeasonGame(g) ? seasonBat(bid) : null;

  if(code==="BB") { bump(s,"BB",1); if(ss) bump(ss,"BB",1); addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → WALK`); walkAdvance(game, bid); nextBatter(game); return; }
  if(code==="K") { bump(s,"AB",1); bump(s,"SO",1); if(ss){ bump(ss,"AB",1); bump(ss,"SO",1); } game.outs += 1; addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → STRIKEOUT`); nextBatter(game); return; }
  if(code.startsWith("FO")) {
    bump(s,"AB",1); if(ss) bump(ss,"AB",1);
    game.outs += 1;
    addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → FLY OUT`);
    if(code==="FO_1"){
      const sideKey = battingSide(g);
      const before = g.score[sideKey];
      advanceAll(game, 1, bid, -1);
      if(g.score[sideKey] > before){
        // Sacrifice fly: RBI counts, but no AB charged
        bump(s,"AB",-1); bump(s,"SF",1);
        if(ss){ bump(ss,"AB",-1); bump(ss,"SF",1); }
        addLog(game, `Sacrifice fly — no AB charged.`);
      }
    }
    nextBatter(game); return;
  }
  if(code.startsWith("GO")) {
    bump(s,"AB",1); if(ss) bump(ss,"AB",1);
    if(code==="GO_L") { const d=fcLeadOut(game,bid); addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → GROUNDBALL → ${d}`); nextBatter(game); return; }
    game.outs += 1; addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → GROUNDBALL, batter out`); if(code==="GO_B1") advanceAll(game, 1, bid, -1); nextBatter(game); return;
  }

  // hits
  bump(s,"AB",1); if(ss) bump(ss,"AB",1);
  if(code==="HR") {
    bump(s,"H",1); bump(s,"HR",1);
    if(ss){ bump(ss,"H",1); bump(ss,"HR",1); }
    addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → HOME RUN`);
    const runners=game.bases.slice();
    for(const r of runners) if(r) creditRun(r);
    const runs = runners.filter(Boolean).length + 1;
    for(let i=0;i<runs;i++) scoreRun(game,bid);
    creditRun(bid);
    game.bases=[null,null,null];
    nextBatter(game);
    return;
  }
  if(code==="3B") { bump(s,"H",1); bump(s,"3B",1); if(ss){ bump(ss,"H",1); bump(ss,"3B",1); } addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → TRIPLE`); advanceAll(game, 3, bid, 2); nextBatter(game); return; }
  if(code.startsWith("2B")) { bump(s,"H",1); bump(s,"2B",1); if(ss){ bump(ss,"H",1); bump(ss,"2B",1); } addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → DOUBLE`); const adv = (code==="2B3") ? 3 : 2; advanceAll(game, adv, bid, 1); nextBatter(game); return; }
  if(code.startsWith("1B")) { bump(s,"H",1); if(ss) bump(ss,"H",1); addLog(game, `${batter.name} rolled ${roll.total} [${roll.d1}+${roll.d2}] → SINGLE`); const adv = (code==="1B2") ? 2 : 1; advanceAll(game, adv, bid, 0); nextBatter(game); return; }
}

function renderTeamsAll(){
  fillTeamSelect(el("homeTeam"));
  fillTeamSelect(el("awayTeam"));
  fillTeamSelect(el("rosterTeam"));
  fillTeamSelect(el("statsTeam"));
  fillTeamSelect(el("pitchTeam"));
  fillTeamSelect(el("pitRosterTeam"));
  fillTeamSelect(el("schedAway"));
  fillTeamSelect(el("schedHome"));
  fillTeamSelect(el("lineupTeam"));
}

function renderPlayPitcherSelectors(){
  const homeId=el("homeTeam").value;
  const awayId=el("awayTeam").value;
  if(el("homePitcher")) fillPitcherSelect(el("homePitcher"), homeId);
  if(el("awayPitcher")) fillPitcherSelect(el("awayPitcher"), awayId);

  const home=getTeam(homeId), away=getTeam(awayId);
  if(el("homePitcher")) el("homePitcher").value = home?.defaultSPId || "";
  if(el("awayPitcher")) el("awayPitcher").value = away?.defaultSPId || "";
}

function openPitchModal(){
  if(!game) return alert("Start a game first.");
  el("pitchModal").classList.add("show");
  el("pitchModal").setAttribute("aria-hidden","false");
  el("pitchAwayName").textContent = `Away: ${getTeam(game.awayId).name}`;
  el("pitchHomeName").textContent = `Home: ${getTeam(game.homeId).name}`;
  fillPitcherSelect(el("pitchAwaySelect"), game.awayId);
  fillPitcherSelect(el("pitchHomeSelect"), game.homeId);
  el("pitchAwaySelect").value = game.pitcher.away || getTeam(game.awayId)?.defaultSPId || "";
  el("pitchHomeSelect").value = game.pitcher.home || getTeam(game.homeId)?.defaultSPId || "";
}
function closePitchModal(){
  el("pitchModal").classList.remove("show");
  el("pitchModal").setAttribute("aria-hidden","true");
}

function renderPlay(){

  if(!game){
    el("inning").textContent="-"; el("half").textContent="-"; el("outs").textContent="-";
    el("score").textContent="Start a game.";
    el("log").textContent="";
    el("b1").classList.remove("on"); el("b2").classList.remove("on"); el("b3").classList.remove("on");
    el("batter").textContent="-"; el("tier").textContent="-"; el("hr").textContent="-";
    if(el("startGame")){
    if(game && isSeasonGame(game) && !game.final) el("startGame").textContent = "Start / Continue (Season)";
    else if(game && !game.final) el("startGame").textContent = "Continue Game";
    else el("startGame").textContent = "Start Game";
  }
  updateScoreboardUI();
  if(el("finalizeGame")) el("finalizeGame").textContent = "Finalize Game";
    renderLiveBoxScore();
    return;
  }
  el("inning").textContent=String(game.inning);
  el("half").textContent=game.half;
  el("outs").textContent=String(game.outs);
  el("b1").classList.toggle("on", !!game.bases[0]);
  el("b2").classList.toggle("on", !!game.bases[1]);
  el("b3").classList.toggle("on", !!game.bases[2]);

  const away=getTeam(game.awayId).name, home=getTeam(game.homeId).name;
  el("score").innerHTML = `<div><b>${away}</b> ${game.score.away}</div><div><b>${home}</b> ${game.score.home}</div>`;

  const bid=batterId(game);
  const batter=getPlayer(bid);
  el("curHomeP").textContent = getPitcher(game.homeId, game.pitcher.home)?.name || "-";
  el("curAwayP").textContent = getPitcher(game.awayId, game.pitcher.away)?.name || "-";

  el("batter").textContent=batter?.name ?? "(missing)";
  el("tier").textContent=tierLabel(batter?.tier ?? "");
  el("hr").textContent=hrLabel(batter?.hr ?? "lt20");
  el("log").textContent=game.log.join("\n");
  if(el("startGame")){
    if(game && isSeasonGame(game) && !game.final) el("startGame").textContent = "Start / Continue (Season)";
    else if(game && !game.final) el("startGame").textContent = "Continue Game";
    else el("startGame").textContent = "Start Game";
  }
  if(el("finalizeGame")){
    if(game.seasonLink?.gameType==="playoff") el("finalizeGame").textContent = "Finalize Game (Playoffs)";
    else if(isSeasonGame(game)) el("finalizeGame").textContent = "Finalize Game (Season)";
    else el("finalizeGame").textContent = "Finalize Game";
  }
  updateScoreboardUI();
  renderLiveBoxScore();
}

function _boxRowForBat(pid, line){
  const p = getPlayer(pid);
  if(!p) return null;
  const ab = Number(line.AB)||0;
  const h  = Number(line.H)||0;
  const avg = ab ? (h/ab) : 0;
  return [p.name, ab, h, Number(line["2B"])||0, Number(line["3B"])||0, Number(line.HR)||0, Number(line.RBI)||0, Number(line.R)||0, Number(line.BB)||0, Number(line.SO)||0, Number(line.SF)||0, avg.toFixed(3).replace(/^0/,"")];
}
function _boxRowForPitch(pid, line){
  const p = getPitcher(game?.awayId, pid) || getPitcher(game?.homeId, pid) || {name:"(unknown)"};
  return [p.name, outsToIP(Number(line.OUTS)||0), Number(line.H)||0, Number(line.R)||0, Number(line.ER)||0, Number(line.HR)||0, Number(line.BB)||0, Number(line.SO)||0];
}

function renderLiveBoxScore(){
  const boxEl = el("liveBox");
  if(!boxEl) return;
  if(!game){
    boxEl.innerHTML = `<div class="small">Start a game to see live stats.</div>`;
    return;
  }
  game.box = game.box || {batting:{}, pitching:{}};
  const away = getTeam(game.awayId);
  const home = getTeam(game.homeId);

  const makeTable = (title, head, rows)=>{
    const thead = `<tr>${head.map(h=>`<th>${h}</th>`).join("")}</tr>`;
    const tbody = rows.length ? rows.map(r=>`<tr>${r.map(v=>`<td>${v}</td>`).join("")}</tr>`).join("")
                              : `<tr><td colspan="${head.length}" class="small">No data yet</td></tr>`;
    return `<div><h3>${title}</h3><div class="miniTable"><table><thead>${thead}</thead><tbody>${tbody}</tbody></table></div></div>`;
  };

  const batHead = ["Player","AB","H","2B","3B","HR","RBI","R","BB","SO","SF","AVG"];
  const pitHead = ["Pitcher","IP","H","R","ER","HR","BB","SO"];

  const awayBatRows = (away?.lineup||[])
    .map(pid=>_boxRowForBat(pid, game.box.batting?.[pid]||{}))
    .filter(Boolean);
  const homeBatRows = (home?.lineup||[])
    .map(pid=>_boxRowForBat(pid, game.box.batting?.[pid]||{}))
    .filter(Boolean);

  const awayPitchers = Object.keys(game.box.pitching||{}).filter(pid=>getPitcher(game.awayId,pid));
  const homePitchers = Object.keys(game.box.pitching||{}).filter(pid=>getPitcher(game.homeId,pid));
  const awayPitRows = awayPitchers.map(pid=>_boxRowForPitch(pid, game.box.pitching[pid]||{}));
  const homePitRows = homePitchers.map(pid=>_boxRowForPitch(pid, game.box.pitching[pid]||{}));

  boxEl.innerHTML = [
    makeTable(`${away?.name||"Away"} Batting`, batHead, awayBatRows),
    makeTable(`${home?.name||"Home"} Batting`, batHead, homeBatRows),
    makeTable(`${away?.name||"Away"} Pitching`, pitHead, awayPitRows),
    makeTable(`${home?.name||"Home"} Pitching`, pitHead, homePitRows),
  ].join("");
}



function renderPitchers(){
  const team=getTeam(el("pitRosterTeam").value);
  const list=el("pitcherList");
  const spSel=el("defaultSP");
  list.innerHTML="";
  spSel.innerHTML="";
  if(!team) return;

  const none=document.createElement("option");
  none.value=""; none.textContent="(none)";
  spSel.appendChild(none);
  for(const p of (team.pitchers||[])){
    const o=document.createElement("option");
    o.value=p.id; o.textContent=`${p.name} (${p.role})`;
    spSel.appendChild(o);
  }
  spSel.value = team.defaultSPId || "";

  for(const p of (team.pitchers||[])){
    ensurePitch(p.id);
    const row=document.createElement("div");
    row.className="row";
    row.innerHTML = `<div class="pill"><b>${p.name}</b> (${p.role})</div>`;
    const edit=document.createElement("button");
    edit.textContent="Edit";
    edit.onclick=()=>openPlayerEdit("pitcher", team.id, p.id);

    const del=document.createElement("button");
    del.className="danger"; del.textContent="Remove";
    del.onclick=()=>{
      if(!confirm(`Remove pitcher ${p.name}?`)) return;
      team.pitchers = team.pitchers.filter(x=>x.id!==p.id);
      if(team.defaultSPId===p.id) team.defaultSPId=null;
      delete state.season.pitching[p.id];
      saveState();
      renderPitchers();
      renderPitching();
      renderPlayPitcherSelectors();
    };
    row.appendChild(edit);
    row.appendChild(del);
    list.appendChild(row);
  }
}

function renderLeague(){
  const div=el("teamsList");
  div.innerHTML="";
  let _li=0;
  for(const t of state.teams){
    ensureTeamStyle(t, _li++);
    const row=document.createElement("div");
    row.className="row";
    row.innerHTML = `<div class="pill">${teamDot(t)}<b>${t.name}</b> — ${t.roster.length} players</div>`;

    const colorIn=document.createElement("input");
    colorIn.type="color"; colorIn.value=t.color; colorIn.title="Team color";
    colorIn.style.width="44px"; colorIn.style.height="34px"; colorIn.style.padding="2px";
    colorIn.onchange=()=>{ t.color=colorIn.value; saveState(); renderLeague(); renderPlay(); };

    const abbrIn=document.createElement("input");
    abbrIn.value=t.abbr; abbrIn.maxLength=4; abbrIn.title="Abbreviation (scoreboard)";
    abbrIn.style.width="64px"; abbrIn.placeholder="ABR";
    abbrIn.onchange=()=>{ t.abbr=(abbrIn.value||makeAbbr(t.name)).toUpperCase().slice(0,4); saveState(); renderLeague(); renderPlay(); };

    row.appendChild(colorIn);
    row.appendChild(abbrIn);
    const del=document.createElement("button");
    del.className="danger"; del.textContent="Delete";
    del.onclick=()=>{
      if(!confirm(`Delete team "${t.name}"?`)) return;
      for(const p of t.roster) delete state.season.batting[p.id];
      state.schedule = state.schedule.filter(g=>g.homeId!==t.id && g.awayId!==t.id);
      state.teams = state.teams.filter(x=>x.id!==t.id);
      saveState();
      renderTeamsAll();
      renderLeague();
      renderSchedule();
      renderPlay();
  renderStandings();
  renderPitching();
    };
    row.appendChild(del);
    div.appendChild(row);
  }
  renderRoster();
  renderLineupEditor();
  if(el("pitRosterTeam")) renderPitchers();
}
function renderRoster(){
  const team=getTeam(el("rosterTeam").value);
  const div=el("rosterList");
  div.innerHTML="";
  if(!team) return;
  for(const p of team.roster){
    const row=document.createElement("div");
    row.className="row";
    row.innerHTML = `<div class="pill"><b>${p.name}</b> (${p.pos})</div><div class="small">${tierLabel(p.tier)} · ${hrLabel(p.hr)}</div>`;
    const edit=document.createElement("button");
    edit.textContent="Edit";
    edit.onclick=()=>openPlayerEdit("batter", team.id, p.id);

    const del=document.createElement("button");
    del.className="danger"; del.textContent="Remove";
    del.onclick=()=>{
      if(!confirm(`Remove ${p.name}?`)) return;
      team.roster = team.roster.filter(x=>x.id!==p.id);
      delete state.season.batting[p.id];
      team.lineup = (team.lineup||[]).filter(id=>id!==p.id);
      saveState();
      renderRoster();
      renderLineupEditor();
      renderPlay();
    };
    row.appendChild(edit);
    row.appendChild(del);
    div.appendChild(row);
  }
}

function battingAvg(s){ return s.AB ? (s.H/s.AB) : 0; }

function ensureDivisions(){
  state.season = state.season || {};
  state.season.structure = state.season.structure || { leagueName:"League", divisions:[] };
  if(!Array.isArray(state.season.structure.divisions)) state.season.structure.divisions=[];
  if(state.season.structure.divisions.length===0){
    state.season.structure.divisions = [
      {id:uid(), name:"East"},
      {id:uid(), name:"West"},
      {id:uid(), name:"North"},
      {id:uid(), name:"South"},
    ];
  }
  const divIds = state.season.structure.divisions.map(d=>d.id);
  let di=0;
  for(const t of state.teams){
    if(!t.divisionId || !divIds.includes(t.divisionId)){
      t.divisionId = divIds[di % divIds.length];
      di++;
    }
  }
}

function computeStandingsForTeamIds(teamIds){
  // Returns array of {teamId, GP,W,L,RF,RA,RD,WPct,GB,L10,Streak}
  const set = new Set(teamIds);
  const map = {};
  for(const tid of teamIds){
    map[tid] = { teamId:tid, GP:0, W:0, L:0, RF:0, RA:0, RD:0, WPct:0, GB:0, L10:"-", Streak:"-", _res:[] };
  }

  const finals = (state.schedule||[])
    .filter(g=>g && g.status==="final")
    .slice()
    .sort((a,b)=>{
      const ta = (a.playedAt ? Date.parse(a.playedAt) : 0) || 0;
      const tb = (b.playedAt ? Date.parse(b.playedAt) : 0) || 0;
      if(ta!==tb) return ta - tb;
      return (Number(a.gameNo)||0) - (Number(b.gameNo)||0);
    });

  for(const g of finals){
    const awayIn = set.has(g.awayId);
    const homeIn = set.has(g.homeId);
    if(!awayIn && !homeIn) continue;

    if(awayIn){
      const away = map[g.awayId];
      away.GP += 1;
      away.RF += g.awayScore; away.RA += g.homeScore;
      if(g.awayScore > g.homeScore){ away.W += 1; away._res.push("W"); }
      else if(g.homeScore > g.awayScore){ away.L += 1; away._res.push("L"); }
    }
    if(homeIn){
      const home = map[g.homeId];
      home.GP += 1;
      home.RF += g.homeScore; home.RA += g.awayScore;
      if(g.homeScore > g.awayScore){ home.W += 1; home._res.push("W"); }
      else if(g.awayScore > g.homeScore){ home.L += 1; home._res.push("L"); }
    }
  }

  const rows = Object.values(map);
  for(const r of rows){
    r.RD = r.RF - r.RA;
    r.WPct = (r.GP ? (r.W / r.GP) : 0);
  }
  rows.sort((a,b)=>{
    if(b.WPct!==a.WPct) return b.WPct - a.WPct;
    if(b.W!==a.W) return b.W - a.W;
    if(b.RD!==a.RD) return b.RD - a.RD;
    return b.RF - a.RF;
  });

  const leader = rows[0] || null;
  for(const r of rows){
    if(!leader) r.GB = 0;
    else {
      r.GB = ((leader.W - r.W) + (r.L - leader.L)) / 2;
      if(!isFinite(r.GB) || Math.abs(r.GB) < 1e-9) r.GB = 0;
    }

    const last10 = (r._res||[]).slice(-10);
    if(last10.length){
      const w10 = last10.filter(x=>x==="W").length;
      const l10 = last10.filter(x=>x==="L").length;
      r.L10 = `${w10}-${l10}`;
    } else r.L10 = "-";

    const res = (r._res||[]);
    if(!res.length) r.Streak = "-";
    else {
      const last = res[res.length-1];
      let n=1;
      for(let i=res.length-2;i>=0;i--){ if(res[i]===last) n++; else break; }
      r.Streak = `${last}${n}`;
    }
  }
  return rows;
}

function makeStandingsTable(rows){
  const tbl=document.createElement("table");
  const head=["Team","W","L","Pct","GB","L10","Strk","RF","RA","RD"];
  const trh=document.createElement("tr");
  head.forEach(h=>{ const th=document.createElement("th"); th.textContent=h; trh.appendChild(th); });
  tbl.appendChild(trh);
  rows.forEach((r,idx)=>{
    const team=getTeam(r.teamId);
    const tr=document.createElement("tr");
    if(idx===0 && r.GP>0) tr.className="leader";
    const gb=(idx===0)?"-":((r.GB%1===0)?String(r.GB):r.GB.toFixed(1));
    const vals=[
      team ? `${teamDot(ensureTeamStyle(team))}${team.name}` : "??",
      r.W, r.L,
      r.WPct.toFixed(3).replace(/^0/,""),
      gb,
      r.L10,
      r.Streak,
      r.RF, r.RA, r.RD
    ];
    vals.forEach((v,ci)=>{ const td=document.createElement("td"); if(ci===0) td.innerHTML=String(v); else td.textContent=String(v); tr.appendChild(td); });
    tbl.appendChild(tr);
  });
  return tbl;
}

function renderDivisionManager(){
  ensureDivisions();
  const list=el("divisionsList");
  const asn=el("divisionAssignments");
  if(!list || !asn) return;

  // Divisions list
  list.innerHTML="";
  const divs = state.season.structure.divisions;
  for(const d of divs){
    const row=document.createElement("div");
    row.className="row";
    const inp=document.createElement("input");
    inp.value=d.name;
    inp.onchange=()=>{ d.name = inp.value.trim() || d.name; saveState(); renderStandings(); };
    const del=document.createElement("button");
    del.className="danger";
    del.textContent="Delete";
    del.onclick=()=>{
      if(divs.length<=1) return alert("You must have at least 1 division.");
      if(!confirm(`Delete division "${d.name}"? Teams in it will move to the first division.`)) return;
      const first = divs.find(x=>x.id!==d.id);
      for(const t of state.teams){
        if(t.divisionId===d.id) t.divisionId = first.id;
      }
      state.season.structure.divisions = divs.filter(x=>x.id!==d.id);
      saveState();
      renderStandings();
    };
    row.appendChild(inp);
    row.appendChild(del);
    list.appendChild(row);
  }

  // Team assignments
  asn.innerHTML="";
  for(const t of state.teams){
    const row=document.createElement("div");
    row.className="row";
    row.innerHTML = `<div class="pill"><b>${t.name}</b></div>`;
    const sel=document.createElement("select");
    for(const d of state.season.structure.divisions){
      const o=document.createElement("option");
      o.value=d.id; o.textContent=d.name;
      if(t.divisionId===d.id) o.selected=true;
      sel.appendChild(o);
    }
    sel.onchange=()=>{ t.divisionId = sel.value; saveState(); renderStandings(); };
    row.appendChild(sel);
    asn.appendChild(row);
  }
}

function renderStandings(){
  const wrap = el("standingsWrap");
  if(!wrap) return;
  ensureDivisions();
  renderDivisionManager();

  const viewSel = el("standingsView");
  const view = viewSel?.value || "division";
  wrap.innerHTML="";

  if(view==="league"){
    const rows = computeStandingsForTeamIds(state.teams.map(t=>t.id));
    const tableWrap=document.createElement("div");
    tableWrap.className="tableWrap";
    tableWrap.appendChild(makeStandingsTable(rows));
    wrap.appendChild(tableWrap);
    return;
  }

  // Division view
  for(const d of state.season.structure.divisions){
    const teamsIn = state.teams.filter(t=>t.divisionId===d.id);
    if(!teamsIn.length) continue;
    const h=document.createElement("h3");
    h.className="h3";
    h.textContent=d.name;
    wrap.appendChild(h);
    const rows = computeStandingsForTeamIds(teamsIn.map(t=>t.id));
    const tableWrap=document.createElement("div");
    tableWrap.className="tableWrap";
    tableWrap.appendChild(makeStandingsTable(rows));
    wrap.appendChild(tableWrap);
  }
}


function renderPitching(){
  const team=getTeam(el("pitchTeam").value);
  const tbl=el("pitchTable");
  tbl.innerHTML="";
  if(!team) return;

  const head=["Pitcher","Role","GP","IP","H","R","ER","HR","BB","SO","W","L","SV","ERA"];
  const trh=document.createElement("tr");
  head.forEach(h=>{ const th=document.createElement("th"); th.textContent=h; trh.appendChild(th); });
  tbl.appendChild(trh);

  for(const p of (team.pitchers||[])){
    ensurePitch(p.id);
    const s=state.season.pitching[p.id];
    const ipOuts=s.OUTS||0;
    const ip=outsToIP(ipOuts);
    const ipInnings = ipOuts/3;
    const era = ipInnings>0 ? (9*getER(s)/ipInnings) : 0;
    const tr=document.createElement("tr");
    const vals=[p.name,p.role,(s.GP||0),ip,s.H,s.R,(s.ER||0),s.HR,s.BB,s.SO,s.W,s.L,s.SV,era.toFixed(2)];
    vals.forEach(v=>{ const td=document.createElement("td"); td.textContent=String(v); tr.appendChild(td); });
    tbl.appendChild(tr);
  }
}

function renderLeaders(){
  const topN = Number(el("leadTopN")?.value || 10);

  // ---------- Batting ----------
  const batCat = el("leadBatCat")?.value || "AB";
  const bat = [];
  for(const t of state.teams){
    for(const p of (t.roster||[])){
      ensureBat(p.id);
      const s = state.season.batting[p.id];
      const ab = Number(s.AB)||0;
      const h  = Number(s.H)||0;
      const bb = Number(s.BB)||0;
      const so = Number(s.SO)||0;
      const hr = Number(s.HR)||0;
      const r  = Number(s.R)||0;
      const rbi= Number(s.RBI)||0;
      const dbl= Number(s["2B"])||0;
      const tpl= Number(s["3B"])||0;
      const sf = Number(s.SF)||0;

      const avg = (ab>0) ? (h/ab) : 0;
      // OBP = (H+BB)/(AB+BB+SF)  (no HBP tracked)
      const obp = ((ab+bb+sf)>0) ? ((h+bb)/(ab+bb+sf)) : 0;
      const singles = Math.max(0, h - dbl - tpl - hr);
      const tb = singles + 2*dbl + 3*tpl + 4*hr;
      const slg = (ab>0) ? (tb/ab) : 0;
      const ops = obp + slg;

      let val = 0;
      if(batCat==="AVG") val = avg;
      else if(batCat==="OBP") val = obp;
      else if(batCat==="SLG") val = slg;
      else if(batCat==="OPS") val = ops;
      else if(batCat==="AB") val = ab;
      else if(batCat==="H") val = h;
      else if(batCat==="HR") val = hr;
      else if(batCat==="RBI") val = rbi;
      else if(batCat==="R") val = r;
      else if(batCat==="BB") val = bb;
      else if(batCat==="SO") val = so;
      else val = Number(s[batCat] ?? 0);

      if(["AVG","OBP","SLG","OPS"].includes(batCat) && ab===0) continue;
      bat.push({ name:p.name, team:t.name, ab, val });
    }
  }
  bat.sort((a,b)=>{
    if(["AVG","OBP","SLG","OPS"].includes(batCat)) return b.val - a.val;
    return (b.val - a.val) || (b.ab - a.ab);
  });

  const batTbl = el("leadBatTable");
  if(batTbl){
    batTbl.innerHTML="";
    const trh=document.createElement("tr");
    ["#","Player","Team","AB", batCat].forEach(h=>{
      const th=document.createElement("th"); th.textContent=h; trh.appendChild(th);
    });
    batTbl.appendChild(trh);
    bat.slice(0, topN).forEach((row,i)=>{
      const tr=document.createElement("tr");
      const displayVal = (["AVG","OBP","SLG","OPS"].includes(batCat))
        ? row.val.toFixed(3).replace(/^0/,"")
        : String(row.val);
      [String(i+1), row.name, row.team, String(row.ab), displayVal].forEach(v=>{
        const td=document.createElement("td"); td.textContent=v; tr.appendChild(td);
      });
      batTbl.appendChild(tr);
    });
  }

  // ---------- Pitching ----------
  const pitCat = el("leadPitCat")?.value || "W";
  const pit = [];
  for(const t of state.teams){
    for(const p of (t.pitchers||[])){
      ensurePitch(p.id);
      const s = state.season.pitching[p.id];
      const outs = Number(s.OUTS||0);
      const ip = outs/3;
      const h  = Number(s.H||0);
      const bb = Number(s.BB||0);
      const so = Number(s.SO||0);
      const w  = Number(s.W||0);
      const l  = Number(s.L||0);
      const sv = Number(s.SV||0);
      const er = getER(s);
      const era  = (outs>0) ? (9*er/ip) : 0;
      const whip = (outs>0) ? ((h+bb)/ip) : 0;

      let val = 0;
      if(pitCat==="ERA") val = era;
      else if(pitCat==="WHIP") val = whip;
      else if(pitCat==="IP") val = ip;
      else if(pitCat==="SO") val = so;
      else if(pitCat==="W") val = w;
      else if(pitCat==="L") val = l;
      else if(pitCat==="SV") val = sv;
      else if(pitCat==="GP") val = Number(s.GP||0);
      else val = Number(s[pitCat] ?? 0);

      if(["ERA","WHIP"].includes(pitCat) && outs<=0) continue;
      pit.push({ name:p.name, team:t.name, outs, val });
    }
  }
  pit.sort((a,b)=>{
    if(["ERA","WHIP"].includes(pitCat)) return a.val - b.val; // lower better
    return (b.val - a.val) || (b.outs - a.outs);
  });

  const pitTbl = el("leadPitTable");
  if(pitTbl){
    pitTbl.innerHTML="";
    const trh=document.createElement("tr");
    ["#","Pitcher","Team","IP", pitCat].forEach(h=>{
      const th=document.createElement("th"); th.textContent=h; trh.appendChild(th);
    });
    pitTbl.appendChild(trh);
    pit.slice(0, topN).forEach((row,i)=>{
      const tr=document.createElement("tr");
      const displayVal = (["ERA","WHIP"].includes(pitCat)) ? row.val.toFixed(2) : String(row.val);
      const ipStr = outsToIP(row.outs);
      [String(i+1), row.name, row.team, ipStr, displayVal].forEach(v=>{
        const td=document.createElement("td"); td.textContent=v; tr.appendChild(td);
      });
      pitTbl.appendChild(tr);
    });
  }
}

function pitcherMeta(pid){
  for(const t of state.teams){
    for(const p of (t.pitchers||[])){
      if(p.id===pid) return {name:p.name, team:t.name, role:p.role, teamId:t.id};
    }
  }
  return {name:(pid||"?") , team:"?", role:"?", teamId:null};
}

function batterMeta(pid){
  for(const t of state.teams){
    for(const p of (t.roster||[])){
      if(p.id===pid) return {name:p.name, team:t.name, pos:p.pos, teamId:t.id};
    }
  }
  return {name:(pid||"?") , team:"?", pos:"?", teamId:null};
}

function awardCard(title, winnerLine, topRows, cols){
  const card=document.createElement("div");
  card.className="card";
  card.style.background="#0b1229";
  card.style.marginTop="12px";

  const h=document.createElement("h3");
  h.className="h3";
  h.textContent=title;
  card.appendChild(h);

  const w=document.createElement("div");
  w.className="pill";
  w.innerHTML = winnerLine;
  card.appendChild(w);

  const tableWrap=document.createElement("div");
  tableWrap.className="tableWrap";
  const tbl=document.createElement("table");
  const trh=document.createElement("tr");
  cols.forEach(c=>{ const th=document.createElement("th"); th.textContent=c; trh.appendChild(th); });
  tbl.appendChild(trh);
  topRows.forEach((r,i)=>{
    const tr=document.createElement("tr");
    const vals=[String(i+1), ...r];
    vals.forEach(v=>{ const td=document.createElement("td"); td.textContent=String(v); tr.appendChild(td); });
    tbl.appendChild(tr);
  });
  tableWrap.appendChild(tbl);
  card.appendChild(tableWrap);
  return card;
}

function renderAwards(){
  const wrap=el("awardsWrap");
  if(!wrap) return;
  wrap.innerHTML="";

  const seasonGamesPlayed = (state.schedule||[]).filter(g=>isSeasonGame(g) && g.status==="played").length;
  const minAB = Math.min(50, Math.max(10, Math.floor(seasonGamesPlayed*1.5) || 10));

  // MVP (hitters)
  const hitters=[];
  for(const pid of Object.keys(state.season?.batting||{})){
    const s=state.season.batting[pid];
    const ab=Number(s.AB)||0;
    if(ab<minAB) continue; // prevent 1-AB "leaders" from winning MVP
    const h=Number(s.H)||0;
    const bb=Number(s.BB)||0;
    const hr=Number(s.HR)||0;
    const rbi=Number(s.RBI)||0;
    const r=Number(s.R)||0;
    const dbl=Number(s["2B"])||0;
    const tpl=Number(s["3B"])||0;
    const singles=Math.max(0, h - dbl - tpl - hr);
    const obp=((ab+bb)>0)?((h+bb)/(ab+bb)):0;
    const tb=singles + 2*dbl + 3*tpl + 4*hr;
    const slg=(ab>0)?(tb/ab):0;
    const ops=obp+slg;
    const avg=(ab>0)?(h/ab):0;
    // MVP formula: heavily favor AVG + power + production (HR/RBI)
    const m=batterMeta(pid);
    const st = state.season?.standings?.[m?.teamId] || null;
    const wp = st ? (num(st.wins)/(Math.max(1, num(st.wins)+num(st.losses)))) : 0;
    const winBonus = wp * 30; // slight bump for winning teams
    const score=(avg*1000) + (hr*35) + (rbi*7) + (ops*100) + (h*2) + winBonus;
    hitters.push({pid, name:m.name, team:m.team, teamId:m.teamId, pos:m.pos, ab, avg, hr, rbi, r, ops, score});
  }
  hitters.sort((a,b)=>b.score-a.score);
  const mvp=hitters[0]||null;
  if(mvp){
    const winnerLine = `<b>${mvp.name}</b> — ${mvp.team} · AVG ${mvp.avg.toFixed(3).replace(/^0/,"")} · HR ${mvp.hr} · RBI ${mvp.rbi} · OPS ${mvp.ops.toFixed(3).replace(/^0/,"")}`;
    const topRows = hitters.slice(0,5).map(x=>[
      x.name,
      x.team,
      x.ab,
      x.avg.toFixed(3).replace(/^0/,""),
      x.hr,
      x.rbi,
      x.ops.toFixed(3).replace(/^0/,""),
      x.r,
    ]);
    wrap.appendChild(awardCard(
      "MVP",
      winnerLine,
      topRows,
      ["#","Player","Team","AB","AVG","HR","RBI","OPS","R"]
    ));
  } else {
    const p=document.createElement("div");
    p.className="small";
    p.textContent = seasonGamesPlayed>0
      ? `Not enough data yet for MVP (min ${minAB} AB).`
      : "No batting stats yet.";
    wrap.appendChild(p);
  }

  // Cy Young (pitchers)
  const pitchers=[];
  for(const pid of Object.keys(state.season?.pitching||{})){
    const s=state.season.pitching[pid];
    const outs=Number(s.OUTS)||0;
    if(outs<=0) continue;
    const ip=outs/3;
    const er=getER(s);
    const h=Number(s.H)||0;
    const bb=Number(s.BB)||0;
    const so=Number(s.SO)||0;
    const w=Number(s.W)||0;
    const sv=Number(s.SV)||0;
    const era=(ip>0)?(9*er/ip):0;
    const whip=(ip>0)?((bb+h)/ip):0;
    const score=(ip*4) + (so*1.5) + (w*6) + (sv*4) - (era*25) - (whip*15);
    const m=pitcherMeta(pid);
    pitchers.push({pid, name:m.name, team:m.team, role:m.role, outs, ip, so, w, sv, era, whip, score});
  }
  pitchers.sort((a,b)=>b.score-a.score);
  const cy=pitchers[0]||null;
  if(cy){
    const winnerLine = `<b>${cy.name}</b> — ${cy.team} · ERA ${cy.era.toFixed(2)} · WHIP ${cy.whip.toFixed(2)} · ${outsToIP(cy.outs)} IP · SO ${cy.so}`;
    const topRows = pitchers.slice(0,5).map(x=>[
      x.name,
      x.team,
      outsToIP(x.outs),
      x.era.toFixed(2),
      x.whip.toFixed(2),
      x.so,
      x.w,
      x.sv,
    ]);
    wrap.appendChild(awardCard("Cy Young", winnerLine, topRows, ["#","Pitcher","Team","IP","ERA","WHIP","SO","W","SV"]));
  }

  // Reliever of the Year (RP)
  const relievers = pitchers.filter(p=>String(p.role||"").toUpperCase()==="RP");
  relievers.forEach(r=>{
    // override score for relievers: saves + dominance
    r.rScore = (r.sv*12) + (r.so*1.2) + (r.ip*1) - (r.era*22) - (r.whip*12);
  });
  relievers.sort((a,b)=>(b.rScore||0)-(a.rScore||0));
  const roy=relievers[0]||null;
  if(roy){
    const winnerLine = `<b>${roy.name}</b> — ${roy.team} · SV ${roy.sv} · ERA ${roy.era.toFixed(2)} · WHIP ${roy.whip.toFixed(2)} · SO ${roy.so}`;
    const topRows = relievers.slice(0,5).map(x=>[
      x.name,
      x.team,
      outsToIP(x.outs),
      x.sv,
      x.era.toFixed(2),
      x.whip.toFixed(2),
      x.so,
      x.w,
    ]);
    wrap.appendChild(awardCard("Reliever of the Year", winnerLine, topRows, ["#","Pitcher","Team","IP","SV","ERA","WHIP","SO","W"]));
  }

  // ---------- All-Stars ----------
  const allHeader=document.createElement("h3");
  allHeader.className="h3";
  allHeader.style.marginTop="18px";
  allHeader.textContent="All-Stars";
  wrap.appendChild(allHeader);

  const allCard=document.createElement("div");
  allCard.className="card";
  allCard.style.background="#0b1229";

  const normPos = (pos)=>{
    const p=String(pos||"").toUpperCase();
    if(["LF","CF","RF","OF","OUTFIELD"].includes(p)) return "OF";
    if(["1B","2B","3B","SS","C"].includes(p)) return p;
    return "";
  };

  const makeTable=(title, cols, rows)=>{
    const sec=document.createElement("div");
    sec.style.marginTop="10px";
    const h=document.createElement("div");
    h.className="pill";
    h.innerHTML = `<b>${title}</b>`;
    sec.appendChild(h);

    const tableWrap=document.createElement("div");
    tableWrap.className="tableWrap";
    const tbl=document.createElement("table");
    const trh=document.createElement("tr");
    cols.forEach(c=>{ const th=document.createElement("th"); th.textContent=c; trh.appendChild(th); });
    tbl.appendChild(trh);
    rows.forEach((r,i)=>{
      const tr=document.createElement("tr");
      const vals=[String(i+1), ...r];
      vals.forEach(v=>{ const td=document.createElement("td"); td.textContent=String(v); tr.appendChild(td); });
      tbl.appendChild(tr);
    });
    tableWrap.appendChild(tbl);
    sec.appendChild(tableWrap);
    return sec;
  };

  // Hitters by position (use MVP score)
  const byPos={C:[], "1B":[], "2B":[], SS:[], "3B":[], OF:[]};
  for(const h of hitters){
    const p=normPos(h.pos);
    if(!p || !byPos[p]) continue;
    byPos[p].push(h);
  }
  Object.keys(byPos).forEach(k=>byPos[k].sort((a,b)=>b.score-a.score));

  const hitterCols=["#","Player","Team","AB","AVG","HR","RBI"];
  const hitterRow = (x)=>[x.name, x.team, x.ab, x.avg.toFixed(3).replace(/^0/,""), x.hr, x.rbi];

  const posOrder=[["C",3],["1B",3],["2B",3],["SS",3],["3B",3],["OF",6]];
  for(const [pos, n] of posOrder){
    const rows = (byPos[pos]||[]).slice(0,n).map(hitterRow);
    if(rows.length) allCard.appendChild(makeTable(pos, hitterCols, rows));
  }

  // Pitchers (use Cy / Reliever formulas)
  const sp = pitchers.filter(p=>String(p.role||"").toUpperCase()==="SP" && p.outs>=15);
  sp.sort((a,b)=>b.score-a.score);
  const spRows = sp.slice(0,4).map(p=>[p.name, p.team, outsToIP(p.outs), p.era.toFixed(2), p.whip.toFixed(2), p.so]);
  if(spRows.length) allCard.appendChild(makeTable("SP", ["#","Pitcher","Team","IP","ERA","WHIP","SO"], spRows));

  const rp = relievers.filter(p=>p.outs>=9);
  rp.sort((a,b)=>(b.rScore||0)-(a.rScore||0));
  const rpRows = rp.slice(0,4).map(p=>[p.name, p.team, outsToIP(p.outs), p.sv, p.era.toFixed(2), p.whip.toFixed(2), p.so]);
  if(rpRows.length) allCard.appendChild(makeTable("RP", ["#","Pitcher","Team","IP","SV","ERA","WHIP","SO"], rpRows));

  wrap.appendChild(allCard);

}


// -------- Playoffs --------
function regularSeasonComplete(){
  const sched = state.schedule||[];
  return sched.length>0 && sched.every(g=>g.status==="final");
}

function teamDivisionId(teamId){ return getTeam(teamId)?.divisionId || null; }

function getDivisionStandings(){
  ensureDivisions();
  const divs = state.season.structure.divisions;
  const out=[];
  for(const d of divs){
    const teams = state.teams.filter(t=>t.divisionId===d.id).map(t=>t.id);
    if(!teams.length) continue;
    const rows = computeStandingsForTeamIds(teams);
    out.push({division:d, rows});
  }
  return out;
}

function seedPlayoffTeams(){
  // Top 2 from each division.
  const divSt = getDivisionStandings();
  const winners=[];
  const runners=[];
  for(const d of divSt){
    if(d.rows[0]) winners.push(d.rows[0]);
    if(d.rows[1]) runners.push(d.rows[1]);
  }
  if(winners.length<4 || runners.length<4) return null;

  // Sort winners 1-4 by record (WPct then RD), runners 5-8 by record.
  const sortRec = (a,b)=>{
    if(b.WPct!==a.WPct) return b.WPct-a.WPct;
    if(b.W!==a.W) return b.W-a.W;
    if(b.RD!==a.RD) return b.RD-a.RD;
    return b.RF-a.RF;
  };
  winners.sort(sortRec);
  runners.sort(sortRec);

  const seededW = winners.map((r,i)=>({seed:i+1, teamId:r.teamId, divisionId:teamDivisionId(r.teamId), rec:r}));
  const seededR = runners.map((r,i)=>({seed:i+5, teamId:r.teamId, divisionId:teamDivisionId(r.teamId), rec:r}));
  return {winners:seededW, runners:seededR};
}

function assignRunnersAvoidingDivisions(seededW, seededR){
  // Backtracking assignment: each winner gets a runner not in same division.
  const prefs = seededW
    .slice()
    .sort((a,b)=>a.seed-b.seed)
    .map(w=>({
      w,
      options: seededR
        .filter(r=>r.divisionId!==w.divisionId)
        .slice()
        .sort((a,b)=>b.seed-a.seed) // winner prefers lowest-ranked opponent
    }));

  const used = new Set();
  const assign = [];

  function dfs(i){
    if(i>=prefs.length) return true;
    const {w, options} = prefs[i];
    for(const r of options){
      if(used.has(r.teamId)) continue;
      used.add(r.teamId);
      assign.push({w, r});
      if(dfs(i+1)) return true;
      assign.pop();
      used.delete(r.teamId);
    }
    return false;
  }

  if(!dfs(0)) return null;
  // Return in seed order 1-4.
  assign.sort((a,b)=>a.w.seed-b.w.seed);
  return assign;
}

function generatePlayoffs(){
  if(!regularSeasonComplete()){
    if(!confirm("Regular season schedule is not fully final. Generate playoffs anyway?")) return;
  }

  const seeded = seedPlayoffTeams();
  if(!seeded) return alert("Need at least 2 teams in each of 4 divisions to generate playoffs.");

  const pairs = assignRunnersAvoidingDivisions(seeded.winners, seeded.runners);
  if(!pairs) return alert("Could not build Round 1 without same-division matchups. Check division assignments.");

  const series = [];
  const mkSeries = (round, homeSeed, awaySeed)=>{
    const homeId = homeSeed.teamId;
    const awayId = awaySeed.teamId;
    return {
      id: uid(),
      round,
      bestOf: 3,
      homeId,
      awayId,
      homeSeed: homeSeed.seed,
      awaySeed: awaySeed.seed,
      winsHome: 0,
      winsAway: 0,
      status: "active",
      games: [] // {id, gameNo, homeId, awayId, status, homeScore, awayScore, playedAt}
    };
  };

  // Round 1: seeds 1-4 host, paired with 5-8 avoiding same division.
  for(const pr of pairs){
    series.push(mkSeries(1, pr.w, pr.r));
  }

  state.season.playoffs = {
    createdAt: new Date().toISOString(),
    rounds: 3,
    series,
    championTeamId: null
  };
  saveState();
  renderPlayoffs();
  showTab("playoffs");
}

function resetPlayoffs(){
  if(!state.season.playoffs) return;
  if(!confirm("Reset playoffs? This will remove the bracket and results.")) return;
  state.season.playoffs = null;
  saveState();
  renderPlayoffs();
}

function seriesIsComplete(s){
  const need = Math.ceil((s.bestOf||3)/2);
  return (s.winsHome>=need) || (s.winsAway>=need);
}

function seriesWinnerTeamId(s){
  if(!seriesIsComplete(s)) return null;
  return (s.winsHome > s.winsAway) ? s.homeId : s.awayId;
}

function seriesLoserTeamId(s){
  if(!seriesIsComplete(s)) return null;
  return (s.winsHome > s.winsAway) ? s.awayId : s.homeId;
}

function advancePlayoffsIfNeeded(){
  const p = state.season.playoffs;
  if(!p) return;
  const r1 = p.series.filter(s=>s.round===1);
  const r2 = p.series.filter(s=>s.round===2);
  const r3 = p.series.filter(s=>s.round===3);

  // Create Round 2 once Round 1 complete.
  if(r2.length===0 && r1.length===4 && r1.every(seriesIsComplete)){
    // Winners keep their original seed for home-field.
    const winners = r1.map(s=>{
      const wid = seriesWinnerTeamId(s);
      const wSeed = (wid===s.homeId) ? s.homeSeed : s.awaySeed;
      return {teamId: wid, seed: wSeed, divisionId: teamDivisionId(wid)};
    }).sort((a,b)=>a.seed-b.seed);

    // Pair as 1v4 and 2v3 by seed.
    const mk = (a,b)=>({seed:a.seed, teamId:a.teamId, divisionId:a.divisionId});
    const sA = {seed:winners[0].seed, teamId:winners[0].teamId, divisionId:winners[0].divisionId};
    const sB = {seed:winners[3].seed, teamId:winners[3].teamId, divisionId:winners[3].divisionId};
    const sC = {seed:winners[1].seed, teamId:winners[1].teamId, divisionId:winners[1].divisionId};
    const sD = {seed:winners[2].seed, teamId:winners[2].teamId, divisionId:winners[2].divisionId};

    const home1 = (sA.seed < sB.seed) ? sA : sB;
    const away1 = (home1===sA) ? sB : sA;
    const home2 = (sC.seed < sD.seed) ? sC : sD;
    const away2 = (home2===sC) ? sD : sC;
    p.series.push({
      id: uid(), round:2, bestOf:3,
      homeId: home1.teamId, awayId: away1.teamId,
      homeSeed: home1.seed, awaySeed: away1.seed,
      winsHome:0, winsAway:0, status:"active", games:[]
    });
    p.series.push({
      id: uid(), round:2, bestOf:3,
      homeId: home2.teamId, awayId: away2.teamId,
      homeSeed: home2.seed, awaySeed: away2.seed,
      winsHome:0, winsAway:0, status:"active", games:[]
    });
  }

  // Create Round 3 once Round 2 complete.
  if(r3.length===0 && p.series.filter(s=>s.round===2).length===2 && p.series.filter(s=>s.round===2).every(seriesIsComplete)){
    const winners = p.series.filter(s=>s.round===2).map(s=>{
      const wid = seriesWinnerTeamId(s);
      const wSeed = (wid===s.homeId) ? s.homeSeed : s.awaySeed;
      return {teamId: wid, seed: wSeed};
    }).sort((a,b)=>a.seed-b.seed);
    const home = winners[0];
    const away = winners[1];
    p.series.push({
      id: uid(), round:3, bestOf:3,
      homeId: home.teamId, awayId: away.teamId,
      homeSeed: home.seed, awaySeed: away.seed,
      winsHome:0, winsAway:0, status:"active", games:[]
    });
  }

  // Champion
  const finals = p.series.filter(s=>s.round===3);
  if(finals.length===1 && seriesIsComplete(finals[0])){
    p.championTeamId = seriesWinnerTeamId(finals[0]);
  }
}

function startNextPlayoffGame(seriesId){
  const p = state.season.playoffs;
  if(!p) return;
  const s = p.series.find(x=>x.id===seriesId);
  if(!s) return;
  if(seriesIsComplete(s)) return alert("Series is complete.");

  const played = (s.games||[]).filter(g=>g.status==="final").length;
  const gameIdx = played + 1;
  // Home field: higher seed is "home" for Games 1 & 3.
  const higherHome = s.homeSeed < s.awaySeed;
  const hostHome = (gameIdx===2) ? !higherHome : higherHome;
  const homeId = hostHome ? s.homeId : s.awayId;
  const awayId = hostHome ? s.awayId : s.homeId;

  // Create a playoff game record in the series.
  const gobj = {
    id: uid(),
    gameNo: `${s.round}-${seriesId.slice(0,4)}-${gameIdx}`,
    homeId, awayId,
    status:"scheduled",
    homeScore:0, awayScore:0,
    playedAt:null,
    seriesId,
    round: s.round,
    gameInSeries: gameIdx
  };
  s.games.push(gobj);
  saveState();

  // Start as a "season-like" game but mark as playoff.
  game = newGame(homeId, awayId);
  game.seasonLink = { scheduleId: gobj.id, gameNo: gobj.gameNo, gameType:"playoff", seriesId };
  game.pitcher.home = getTeam(homeId)?.defaultSPId || "";
  game.pitcher.away = getTeam(awayId)?.defaultSPId || "";
  notePitcherEntry("home", game.pitcher.home);
  notePitcherEntry("away", game.pitcher.away);
  addLog(game, `Playoff game loaded: Round ${s.round}, Game ${gameIdx} (Best of 3).`);
  saveState();
  showTab("play");
  renderPlay();
}

function finalizePlayoffGame(){
  if(!game) return alert("No active game.");
  if(!game.seasonLink || game.seasonLink.gameType!=="playoff") return alert("Not a playoff game.");
  if(!game.final){
    if(!confirm("Game is not final (may be tied). Finalize anyway?")) return;
  }
  const p = state.season.playoffs;
  if(!p) return alert("No playoff bracket found.");
  const seriesId = game.seasonLink.seriesId;
  const s = p.series.find(x=>x.id===seriesId);
  if(!s) return alert("Series not found.");

  const gobj = (s.games||[]).find(x=>x.id===game.seasonLink.scheduleId);
  if(!gobj) return alert("Playoff game record not found.");

  gobj.status="final";
  gobj.homeScore = game.score.home;
  gobj.awayScore = game.score.away;
  gobj.playedAt = new Date().toISOString();

  // ---- Playoff stats (separate from regular season) ----
  // Batting: sum per-game box lines into playoff totals.
  if(game.box?.batting){
    for(const pid of Object.keys(game.box.batting)){
      const line = game.box.batting[pid];
      if(!line) continue;
      const ps = playoffBat(pid);
      for(const k of Object.keys(_initBatLine())){
        ps[k] = num(ps[k]) + num(line[k]);
      }
      // games played for hitters
      ps.G = num(ps.G) + 1;
    }
  }
  // Pitching: sum per-game pitching lines into playoff totals.
  if(game.box?.pitching){
    for(const pid of Object.keys(game.box.pitching)){
      const line = game.box.pitching[pid];
      if(!line) continue;
      const ps = playoffPitch(pid);
      for(const k of Object.keys(_initPitchLine())){
        // GP handled below; W/L/SV handled via decisions
        if(["GP","W","L","SV"].includes(k)) continue;
        ps[k] = num(ps[k]) + num(line[k]);
      }
    }
  }

  // Pitcher decisions for playoffs (W/L/SV)
  const dec = computePitcherDecisions(game);
  if(dec?.winner){
    if(dec.winPid){ const ps=playoffPitch(dec.winPid); ps.W = num(ps.W)+1; }
    if(dec.lossPid){ const ps=playoffPitch(dec.lossPid); ps.L = num(ps.L)+1; }
    if(dec.savePid){ const ps=playoffPitch(dec.savePid); ps.SV = num(ps.SV)+1; }
  }

  // GP for pitchers who appeared
  const appeared = Object.keys(game.decision?.pitcherEntries || {});
  for(const pid of appeared){
    if(!pid) continue;
    const ps = playoffPitch(pid);
    ps.GP = num(ps.GP) + 1;
  }

  // Update series wins
  if(game.score.home > game.score.away) s.winsHome += (gobj.homeId===s.homeId) ? 1 : 0;
  if(game.score.home > game.score.away) s.winsAway += (gobj.homeId===s.awayId) ? 1 : 0;
  if(game.score.away > game.score.home) s.winsHome += (gobj.awayId===s.homeId) ? 1 : 0;
  if(game.score.away > game.score.home) s.winsAway += (gobj.awayId===s.awayId) ? 1 : 0;

  if(seriesIsComplete(s)) s.status="final";
  advancePlayoffsIfNeeded();
  saveState();
  renderPlayoffs();
  alert(`Finalized playoff game: ${getTeam(gobj.awayId)?.name||"Away"} ${gobj.awayScore} - ${gobj.homeScore} ${getTeam(gobj.homeId)?.name||"Home"}`);
}

function renderPlayoffs(){
  const wrap = el("playoffsWrap");
  if(!wrap) return;
  wrap.innerHTML="";
  const p = state.season.playoffs;
  if(!p){
    wrap.innerHTML = `<div class="hint" style="padding:10px">No playoff bracket yet. Click “Generate Playoff Bracket”.</div>`;
    renderPlayoffLeaders();
    return;
  }
  advancePlayoffsIfNeeded();
  const champ = p.championTeamId ? (getTeam(p.championTeamId)?.name || "?") : null;
  if(champ){
    const h=document.createElement("div");
    h.className="pill";
    h.innerHTML = `<b>Champion:</b> ${champ}`;
    wrap.appendChild(h);
  }

  // --- Bracket visual ---
  const r1 = p.series.filter(s=>s.round===1).slice().sort((a,b)=>a.homeSeed-b.homeSeed);
  const r2 = p.series.filter(s=>s.round===2).slice().sort((a,b)=>a.homeSeed-b.homeSeed);
  const r3 = p.series.filter(s=>s.round===3).slice().sort((a,b)=>a.homeSeed-b.homeSeed);

  const bracket=document.createElement("div");
  bracket.className="bracket";

  const mkRoundCol = (title)=>{
    const col=document.createElement("div");
    col.className="bracketRound";
    const h=document.createElement("div");
    h.className="bracketRoundTitle";
    h.textContent=title;
    col.appendChild(h);
    return col;
  };

  const mkMatch = (s)=>{
    const box=document.createElement("div");
    box.className="match";
    const homeT=getTeam(s.homeId), awayT=getTeam(s.awayId);
    const homeName=homeT?`${teamDot(ensureTeamStyle(homeT))}${homeT.name}`:"?";
    const awayName=awayT?`${teamDot(ensureTeamStyle(awayT))}${awayT.name}`:"?";
    const need=Math.ceil((s.bestOf||3)/2);
    const done=seriesIsComplete(s);
    box.innerHTML = `
      <div class="matchRow ${done && seriesWinnerTeamId(s)===s.homeId?"winner":""}">
        <span class="seed">${s.homeSeed}</span>
        <span class="team">${homeName}</span>
        <span class="wins">${s.winsHome}</span>
      </div>
      <div class="matchRow ${done && seriesWinnerTeamId(s)===s.awayId?"winner":""}">
        <span class="seed">${s.awaySeed}</span>
        <span class="team">${awayName}</span>
        <span class="wins">${s.winsAway}</span>
      </div>
      <div class="matchMeta">
        <span class="small">Best of ${s.bestOf||3} · First to ${need}</span>
      </div>
    `;

    const btn=document.createElement("button");
    btn.className="primary";
    btn.textContent = done ? "Series Complete" : "Play Next Game";
    btn.disabled = done;
    btn.onclick = ()=>startNextPlayoffGame(s.id);
    box.appendChild(btn);

    if((s.games||[]).length){
      const list=document.createElement("div");
      list.className="matchGames";
      for(const g of s.games){
        const res = g.status==="final" ? `${getTeam(g.awayId)?.name||"?"} ${g.awayScore} @ ${getTeam(g.homeId)?.name||"?"} ${g.homeScore}` : `${getTeam(g.awayId)?.name||"?"} @ ${getTeam(g.homeId)?.name||"?"} (sched)`;
        const d=document.createElement("div");
        d.className="small";
        d.textContent = `G${g.gameInSeries}: ${res}`;
        list.appendChild(d);
      }
      box.appendChild(list);
    }

    return box;
  };

  const col1=mkRoundCol("Round 1");
  const col2=mkRoundCol("Round 2");
  const col3=mkRoundCol("Finals");

  // Layout slots: 12-row grid. Round1 matches occupy rows (1,4,7,10) span 3.
  // Round2 occupy rows (2,8) span 6. Finals occupies full height.
  const place = (col, node, rowStart, rowSpan)=>{
    node.style.gridRow = `${rowStart} / span ${rowSpan}`;
    col.appendChild(node);
  };

  for(let i=0;i<r1.length;i++) place(col1, mkMatch(r1[i]), 1 + i*3, 3);
  for(let i=0;i<r2.length;i++) place(col2, mkMatch(r2[i]), 2 + i*6, 6);
  if(r3[0]) place(col3, mkMatch(r3[0]), 1, 12);

  bracket.appendChild(col1);
  bracket.appendChild(col2);
  bracket.appendChild(col3);
  wrap.appendChild(bracket);

  renderPlayoffLeaders();
}

function renderPlayoffLeaders(){
  const wrap = el("playoffLeadersWrap");
  if(!wrap) return;
  const stats = state.season?.playoffStats || {batting:{}, pitching:{}};
  const bat = stats.batting || {};
  const pit = stats.pitching || {};

  const typeSel = el("poLeadType");
  const catSel  = el("poLeadCat");
  const tbl     = el("poLeadTable");
  if(!typeSel || !catSel || !tbl) return;

  // Rebuild category options based on type
  const type = typeSel.value || "bat";
  const batCats = ["OPS","AVG","HR","RBI","H","R","OBP","SLG"];
  const pitCats = ["ERA","WHIP","SO","SV","W","IP","GP"];
  const cats = (type==="pit") ? pitCats : batCats;
  if(!cats.includes(catSel.value)) catSel.value = cats[0];
  catSel.innerHTML = "";
  cats.forEach(c=>{ const o=document.createElement("option"); o.value=c; o.textContent=c; catSel.appendChild(o); });
  catSel.value = catSel.value || cats[0];

  const cat = catSel.value;
  const rows=[];

  if(type==="bat"){
    for(const t of state.teams){
      for(const p of (t.roster||[])){
        const s = bat[p.id];
        if(!s) continue;
        const ab=num(s.AB), h=num(s.H), bb=num(s.BB), hr=num(s.HR), r=num(s.R), rbi=num(s.RBI);
        const dbl=num(s["2B"]), tpl=num(s["3B"]);
        const avg=(ab>0)?(h/ab):0;
        const obp=((ab+bb)>0)?((h+bb)/(ab+bb)):0;
        const singles=Math.max(0, h - dbl - tpl - hr);
        const tb = singles + 2*dbl + 3*tpl + 4*hr;
        const slg=(ab>0)?(tb/ab):0;
        const ops=obp+slg;
        let val=0;
        if(cat==="AVG") val=avg;
        else if(cat==="OBP") val=obp;
        else if(cat==="SLG") val=slg;
        else if(cat==="OPS") val=ops;
        else if(cat==="HR") val=hr;
        else if(cat==="RBI") val=rbi;
        else if(cat==="H") val=h;
        else if(cat==="R") val=r;
        if(["AVG","OBP","SLG","OPS"].includes(cat) && ab<=0) continue;
        rows.push({name:p.name, team:t.name, ab, val});
      }
    }
    rows.sort((a,b)=>{
      if(["AVG","OBP","SLG","OPS"].includes(cat)) return b.val-a.val;
      return (b.val-a.val) || (b.ab-a.ab);
    });
    tbl.innerHTML="";
    const trh=document.createElement("tr");
    ["#","Player","Team","AB",cat].forEach(h=>{ const th=document.createElement("th"); th.textContent=h; trh.appendChild(th); });
    tbl.appendChild(trh);
    rows.slice(0,10).forEach((r,i)=>{
      const tr=document.createElement("tr");
      const displayVal = (["AVG","OBP","SLG","OPS"].includes(cat)) ? r.val.toFixed(3).replace(/^0/,"") : String(r.val);
      [i+1, r.name, r.team, r.ab, displayVal].forEach(v=>{ const td=document.createElement("td"); td.textContent=String(v); tr.appendChild(td); });
      tbl.appendChild(tr);
    });
  } else {
    for(const t of state.teams){
      for(const pch of (t.pitchers||[])){
        const s = pit[pch.id];
        if(!s) continue;
        const outs=num(s.OUTS);
        const ip=outs/3;
        const h=num(s.H), bb=num(s.BB), so=num(s.SO), w=num(s.W), sv=num(s.SV);
        const er=getER(s);
        const era = (outs>0)?(9*er/ip):0;
        const whip=(outs>0)?((h+bb)/ip):0;
        let val=0;
        if(cat==="ERA") val=era;
        else if(cat==="WHIP") val=whip;
        else if(cat==="SO") val=so;
        else if(cat==="W") val=w;
        else if(cat==="SV") val=sv;
        else if(cat==="IP") val=ip;
        else if(cat==="GP") val=num(s.GP);
        if(["ERA","WHIP"].includes(cat) && outs<=0) continue;
        rows.push({name:pch.name, team:t.name, outs, val});
      }
    }
    rows.sort((a,b)=>{
      if(["ERA","WHIP"].includes(cat)) return a.val-b.val;
      return (b.val-a.val) || (b.outs-a.outs);
    });
    tbl.innerHTML="";
    const trh=document.createElement("tr");
    ["#","Pitcher","Team","IP",cat].forEach(h=>{ const th=document.createElement("th"); th.textContent=h; trh.appendChild(th); });
    tbl.appendChild(trh);
    rows.slice(0,10).forEach((r,i)=>{
      const tr=document.createElement("tr");
      const displayVal = (["ERA","WHIP"].includes(cat)) ? r.val.toFixed(2) : String(r.val);
      [i+1, r.name, r.team, outsToIP(r.outs), displayVal].forEach(v=>{ const td=document.createElement("td"); td.textContent=String(v); tr.appendChild(td); });
      tbl.appendChild(tr);
    });
  }
}

function renderStats(){

  const team=getTeam(el("statsTeam").value);
  const tbl=el("battingTable");
  tbl.innerHTML="";
  if(!team) return;
  const head=["Player","AB","H","2B","3B","HR","RBI","R","BB","SO","SF","AVG"];
  const trh=document.createElement("tr");
  head.forEach(h=>{ const th=document.createElement("th"); th.textContent=h; trh.appendChild(th); });
  tbl.appendChild(trh);
  for(const p of team.roster){
    ensureBat(p.id);
    const s=state.season.batting[p.id];
    const tr=document.createElement("tr");
    const vals=[`${p.name} (${p.pos})`,s.AB,s.H,s["2B"],s["3B"],s.HR,s.RBI,s.R,s.BB,s.SO,(s.SF||0),battingAvg(s).toFixed(3).replace(/^0/,"")];
    vals.forEach(v=>{ const td=document.createElement("td"); td.textContent=String(v); tr.appendChild(td); });
    tbl.appendChild(tr);
  }
}


/*** Franchise mode: archive seasons, carry rosters forward ***/
function seasonChampionName(){
  const cid = state.season?.playoffs?.championTeamId || null;
  return cid ? (getTeam(cid)?.name || null) : null;
}

function startNewSeason(){
  const sn = state.franchise?.seasonNumber || 1;
  const champ = seasonChampionName();
  if(!champ){
    if(!confirm(`No playoff champion has been crowned for Season ${sn}.\n\nArchive it and start Season ${sn+1} anyway?`)) return;
  } else {
    if(!confirm(`Archive Season ${sn} (Champion: ${champ}) and start Season ${sn+1}?\n\nTeams, rosters, lineups, pitching staffs, and divisions all carry over.\nStats, standings, schedule, and playoffs are saved to History and reset.\n\nOffseason re-rating: each batter's actual AVG becomes his new BA tier and ${RERATE_HR_THRESHOLD}+ HR puts him on the 20+ HR chart. Players with 0 AB keep last year's ratings.`)) return;
  }

  const divName = (id)=> (state.season.structure?.divisions||[]).find(d=>d.id===id)?.name || "";
  const standRows = computeStandingsForTeamIds(state.teams.map(t=>t.id)).map(r=>({
    name: getTeam(r.teamId)?.name || "?",
    division: divName(getTeam(r.teamId)?.divisionId),
    GP:r.GP, W:r.W, L:r.L,
    Pct: r.WPct.toFixed(3).replace(/^0/,""),
    RF:r.RF, RA:r.RA, RD:r.RD
  }));

  const snapBatLine = (pid)=>{ const s = state.season.batting[pid]; return s ? JSON.parse(JSON.stringify(s)) : _initBatLine(); };
  const snapPitchLine = (pid)=>{ const s = state.season.pitching[pid]; return s ? JSON.parse(JSON.stringify(s)) : _initPitchLine(); };

  const snapshot = {
    id: uid(),
    seasonNumber: sn,
    completedAt: new Date().toISOString(),
    champion: champ,
    gamesPlayed: (state.schedule||[]).filter(g=>g.status==="final").length,
    standings: standRows,
    teams: state.teams.map(t=>({
      name: t.name,
      division: divName(t.divisionId),
      batters: (t.roster||[]).map(p=>({ name:p.name, pos:p.pos, line: snapBatLine(p.id) })),
      pitchers: (t.pitchers||[]).map(p=>({ name:p.name, role:p.role||"", line: snapPitchLine(p.id) }))
    }))
  };

  // Offseason re-rating (house rule): each batter's actual season AVG sets next
  // season's BA tier; actual HR total sets the HR group. Requires RERATE_MIN_AB.
  const reRating = [];
  for(const t of state.teams){
    for(const p of (t.roster||[])){
      const s = state.season.batting[p.id];
      const ab = Number(s?.AB)||0;
      if(ab < RERATE_MIN_AB) continue;
      const avg = (Number(s.H)||0)/ab;
      const hrN = Number(s.HR)||0;
      const newTier = avgToTier(avg);
      const newHr = hrN >= RERATE_HR_THRESHOLD ? "ge20" : "lt20";
      if(newTier !== p.tier || newHr !== p.hr){
        reRating.push({
          team: t.name, name: p.name,
          avg: avg.toFixed(3).replace(/^0/,""), hr: hrN,
          fromTier: tierLabel(p.tier), toTier: tierLabel(newTier),
          fromHr: hrLabel(p.hr), toHr: hrLabel(newHr)
        });
        p.tier = newTier;
        p.hr = newHr;
      }
    }
  }
  snapshot.reRating = reRating;

  state.franchise = state.franchise || { seasonNumber:1, history:[] };
  state.franchise.history.push(snapshot);
  state.franchise.seasonNumber = sn + 1;

  // Reset season-scoped data; keep teams/rosters/lineups/pitchers/divisions
  state.season = {
    batting:{}, pitching:{}, standings:{}, gameLog:[],
    structure: state.season.structure,   // divisions carry over
    playoffs: null,
    playoffStats: { batting:{}, pitching:{} }
  };
  state.schedule = [];
  state.gameHistory = [];
  state.ticker = { queue: [], last: { HR: null } };
  game = null;

  saveState();
  renderSeasonBadge();
  renderTeamsAll(); renderLeague(); renderSchedule(); renderStats(); renderLeaders();
  renderStandings(); renderAwards(); renderPlayoffs(); renderPitching(); renderPlay();
  renderHistory();
  alert(`Season ${sn} archived. Welcome to Season ${state.franchise.seasonNumber}!` + (reRating.length ? `\n\nOffseason re-rating: ${reRating.length} player${reRating.length===1?"":"s"} changed tier/HR group (see History tab).` : `\n\nOffseason re-rating: no tier changes.`));
}

function deleteHistorySeason(){
  const sel = el("histSeason");
  if(!sel || sel.value==="") return;
  const idx = Number(sel.value);
  const h = (state.franchise?.history||[])[idx];
  if(!h) return;
  const what = `Season ${h.seasonNumber}${h.champion ? ` (Champion: ${h.champion})` : ""}${h.imported ? " — imported" : ""}`;
  if(!confirm(`Delete ${what} from franchise history?\n\nThis removes its standings, stats, and records-book contribution. This cannot be undone (export a JSON backup first if unsure).`)) return;
  state.franchise.history.splice(idx, 1);
  saveState();
  renderHistory();
  renderRecords();
  renderSeasonBadge();
}

function renderSeasonBadge(){
  const b = el("seasonBadge");
  if(b) b.textContent = `Season ${state.franchise?.seasonNumber || 1}`;
}

function _histTable(head, rows){
  const thead = `<tr>${head.map(h=>`<th>${h}</th>`).join("")}</tr>`;
  const tbody = rows.length
    ? rows.map(r=>`<tr>${r.map(v=>`<td>${v}</td>`).join("")}</tr>`).join("")
    : `<tr><td colspan="${head.length}" class="small">No data</td></tr>`;
  return `<table><thead>${thead}</thead><tbody>${tbody}</tbody></table>`;
}

function renderHistory(){
  const sel = el("histSeason");
  const info = el("histInfo");
  const standEl = el("histStandings");
  const batEl = el("histBatting");
  const pitEl = el("histPitching");
  if(!sel) return;

  const hist = state.franchise?.history || [];
  const prevPick = sel.value;
  sel.innerHTML = "";
  if(!hist.length){
    if(info) info.innerHTML = `<div class="small">No archived seasons yet. Finish a season (ideally crown a playoff champion), then click "Start New Season".</div>`;
    if(standEl) standEl.innerHTML = "";
    if(batEl) batEl.innerHTML = "";
    if(pitEl) pitEl.innerHTML = "";
    return;
  }
  for(let i=hist.length-1; i>=0; i--){
    const h = hist[i];
    const opt = document.createElement("option");
    opt.value = String(i);
    opt.textContent = `Season ${h.seasonNumber}` + (h.champion ? ` — ${h.champion}` : "");
    sel.appendChild(opt);
  }
  if(prevPick && [...sel.options].some(o=>o.value===prevPick)) sel.value = prevPick;

  const h = hist[Number(sel.value)];
  if(!h) return;

  // team filter for this season's tables
  const tSel = el("histTeam");
  let teamFilter = "all";
  if(tSel){
    const prevTeam = tSel.value || "all";
    tSel.innerHTML = "";
    const allOpt = document.createElement("option");
    allOpt.value="all"; allOpt.textContent="All Teams";
    tSel.appendChild(allOpt);
    for(const t of (h.teams||[])){
      const o=document.createElement("option");
      o.value=t.name; o.textContent=t.name;
      tSel.appendChild(o);
    }
    if(prevTeam!=="all" && (h.teams||[]).some(t=>t.name===prevTeam)) tSel.value = prevTeam;
    teamFilter = tSel.value || "all";
  }
  const teamPass = (name)=> teamFilter==="all" || name===teamFilter;

  const when = h.completedAt ? new Date(h.completedAt).toLocaleDateString() : "";
  if(info) info.innerHTML = `<div class="row"><span class="pill">Season ${h.seasonNumber}</span><span class="pill">${h.gamesPlayed} games</span><span class="pill">${h.champion ? "🏆 " + h.champion : "No champion recorded"}</span><span class="pill">Archived ${when}</span></div>`;

  if(standEl){
    standEl.innerHTML = _histTable(
      ["Team","Div","GP","W","L","Pct","RF","RA","RD"],
      h.standings.map(r=>[r.name, r.division, r.GP, r.W, r.L, r.Pct, r.RF, r.RA, r.RD])
    );
  }

  if(batEl){
    const rows = [];
    for(const t of h.teams){
      if(!teamPass(t.name)) continue;
      for(const p of t.batters){
        const s = p.line || {};
        const ab = Number(s.AB)||0, hh = Number(s.H)||0;
        if(!ab && !Number(s.BB) && !Number(s.R)) continue; // skip empty lines
        rows.push([t.name, `${p.name} (${p.pos||""})`, ab, hh, s["2B"]||0, s["3B"]||0, s.HR||0, s.RBI||0, s.R||0, s.BB||0, s.SO||0, s.SF||0, (ab? (hh/ab):0).toFixed(3).replace(/^0/,"")]);
      }
    }
    batEl.innerHTML = _histTable(["Team","Player","AB","H","2B","3B","HR","RBI","R","BB","SO","SF","AVG"], rows);
  }

  const rrEl = el("histReRating");
  if(rrEl){
    const rr = (h.reRating||[]).filter(r=>teamPass(r.team));
    if(rr.length){
      rrEl.innerHTML = _histTable(
        ["Team","Player","AVG","HR","Tier (old → new)","HR Group (old → new)"],
        rr.map(r=>[r.team, r.name, r.avg, r.hr,
          (r.fromTier!==r.toTier) ? `${r.fromTier} → ${r.toTier}` : r.toTier,
          (r.fromHr!==r.toHr) ? `${r.fromHr} → ${r.toHr}` : r.toHr])
      );
    } else {
      rrEl.innerHTML = `<div class="small">${h.imported ? "Imported season — no re-rating data." : (h.reRating&&h.reRating.length ? "No tier changes for this team." : "No tier changes this offseason.")}</div>`;
    }
  }

  if(pitEl){
    const rows = [];
    for(const t of h.teams){
      if(!teamPass(t.name)) continue;
      for(const p of t.pitchers){
        const s = p.line || {};
        const outs = Number(s.OUTS)||0;
        if(!outs && !Number(s.GP)) continue;
        const era = outs ? ((getER(s)*9)/(outs/3)) : 0;
        rows.push([t.name, p.name, s.GP||0, outsToIP(outs), s.H||0, s.R||0, getER(s), s.HR||0, s.BB||0, s.SO||0, s.W||0, s.L||0, s.SV||0, era.toFixed(2)]);
      }
    }
    pitEl.innerHTML = _histTable(["Team","Pitcher","GP","IP","H","R","ER","HR","BB","SO","W","L","SV","ERA"], rows);
  }
}



/*** Historical season import (CSV) — for pre-app seasons played by hand ***/
function parseCsv(text){
  const rows=[]; let row=[], field="", inQ=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(inQ){
      if(c==='"'){ if(text[i+1]==='"'){ field+='"'; i++; } else inQ=false; }
      else field+=c;
    } else {
      if(c==='"') inQ=true;
      else if(c===","){ row.push(field); field=""; }
      else if(c==="\n" || c==="\r"){
        if(c==="\r" && text[i+1]==="\n") i++;
        row.push(field); field="";
        if(row.some(x=>x.trim()!=="")) rows.push(row);
        row=[];
      }
      else field+=c;
    }
  }
  row.push(field);
  if(row.some(x=>x.trim()!=="")) rows.push(row);
  return rows;
}

function ipToOuts(ip){
  const s = String(ip||"").trim();
  if(!s) return 0;
  const parts = s.split(".");
  const whole = Number(parts[0])||0;
  const frac = Number(parts[1]?.[0])||0; // .1 = 1 out, .2 = 2 outs
  return whole*3 + Math.min(frac,2);
}

const HIST_TEMPLATE_HEADER = ["Section","Season","Team","Player","Pos","AB","H","2B","3B","HR","RBI","R","BB","SO","SF","GP","IP","P_H","P_R","P_ER","P_HR","P_BB","P_SO","W","L","SV","MVP"];

function downloadHistTemplate(){
  const rows = [
    HIST_TEMPLATE_HEADER,
    ["Batting","1","Tigers","John Smith","SS","210","63","12","2","18","55","48","20","30","3","","","","","","","","","","","","4"],
    ["Pitching","1","Tigers","Bob Jones","","","","","","","","","","","","14","88.2","75","40","38","9","25","70","8","4","0",""],
    ["Record","1","Tigers","","","","","","","","","","","","","","","","","","","","","30","18","",""],
    ["Champion","1","Tigers","","","","","","","","","","","","","","","","","","","","","","","",""],
  ];
  downloadText("BHBL_History_Import_Template.csv", toCsv(rows));
  alert("Template downloaded.\n\nRow types:\n• Batting — one row per player per season (AB through SF)\n• Pitching — one row per pitcher per season (GP, IP like 88.2, then pitching H/R/ER/HR/BB/SO, W, L, SV)\n• Record — one row per team per season: W and L go in the W/L columns\n• Champion — one row per season: Team = champion\n\nLeave unused columns empty. SF and MVP can be blank if you didn't track them. IP uses baseball notation (88.2 = 88⅔). Use the same player spelling across seasons so career totals connect.");
}

function importHistoricalCsv(){
  const f = el("histImportFile")?.files?.[0];
  if(!f) return alert("Choose a CSV file first (download the template for the format).");
  f.text().then(txt=>{
    try{
      const rows = parseCsv(txt);
      if(rows.length < 2) throw new Error("CSV has no data rows.");
      const head = rows[0].map(h=>String(h).trim().toLowerCase());
      const col = {};
      HIST_TEMPLATE_HEADER.forEach(h=>{ col[h] = head.indexOf(h.toLowerCase()); });
      if(col.Section<0 || col.Season<0 || col.Team<0) throw new Error("Missing required columns: Section, Season, Team. Download the template for the exact header.");

      const get = (r,name)=> (col[name]>=0 ? String(r[col[name]]??"").trim() : "");
      const getN = (r,name)=> Number(get(r,name))||0;

      const seasons = new Map(); // seasonNumber -> {champion, records:[], teams:Map name->{batters,pitchers}}
      const getSeason = (sn)=>{
        if(!seasons.has(sn)) seasons.set(sn, { champion:null, records:[], teams:new Map() });
        return seasons.get(sn);
      };
      const getSeasonTeam = (S, name)=>{
        if(!S.teams.has(name)) S.teams.set(name, { name, batters:[], pitchers:[] });
        return S.teams.get(name);
      };

      let nBat=0, nPit=0, nRec=0, nChamp=0, skippedRows=0;
      for(let i=1;i<rows.length;i++){
        const r = rows[i];
        const sec = get(r,"Section").toLowerCase();
        const sn = Number(get(r,"Season"));
        const teamName = get(r,"Team");
        if(!sec || !Number.isFinite(sn) || sn<=0 || !teamName){ skippedRows++; continue; }
        const S = getSeason(sn);

        if(sec==="batting"){
          const player = get(r,"Player");
          if(!player){ skippedRows++; continue; }
          const line = _initBatLine();
          line.AB=getN(r,"AB"); line.H=getN(r,"H"); line["2B"]=getN(r,"2B"); line["3B"]=getN(r,"3B");
          line.HR=getN(r,"HR"); line.RBI=getN(r,"RBI"); line.R=getN(r,"R"); line.BB=getN(r,"BB");
          line.SO=getN(r,"SO"); line.SF=getN(r,"SF");
          const mvp = getN(r,"MVP"); if(mvp) line.MVP = mvp;
          getSeasonTeam(S, teamName).batters.push({ name:player, pos:get(r,"Pos"), line });
          nBat++;
        } else if(sec==="pitching"){
          const player = get(r,"Player");
          if(!player){ skippedRows++; continue; }
          const line = _initPitchLine();
          line.GP=getN(r,"GP"); line.OUTS=ipToOuts(get(r,"IP"));
          line.H=getN(r,"P_H"); line.R=getN(r,"P_R"); line.ER=getN(r,"P_ER");
          line.HR=getN(r,"P_HR"); line.BB=getN(r,"P_BB"); line.SO=getN(r,"P_SO");
          line.W=getN(r,"W"); line.L=getN(r,"L"); line.SV=getN(r,"SV");
          getSeasonTeam(S, teamName).pitchers.push({ name:player, role:"", line });
          nPit++;
        } else if(sec==="record"){
          S.records.push({ name:teamName, W:getN(r,"W"), L:getN(r,"L") });
          nRec++;
        } else if(sec==="champion"){
          S.champion = teamName;
          nChamp++;
        } else {
          skippedRows++;
        }
      }
      if(!seasons.size) throw new Error("No valid rows found.");

      state.franchise = state.franchise || { seasonNumber:1, history:[] };
      const existing = new Set(state.franchise.history.map(h=>Number(h.seasonNumber)));
      const skippedSeasons = [];
      let added = 0, maxSn = 0;

      const sortedSns = [...seasons.keys()].sort((a,b)=>a-b);
      for(const sn of sortedSns){
        maxSn = Math.max(maxSn, sn);
        if(existing.has(sn)){ skippedSeasons.push(sn); continue; }
        const S = seasons.get(sn);
        const standings = S.records
          .slice()
          .sort((a,b)=>(b.W-b.L)-(a.W-a.L))
          .map(rec=>({
            name: rec.name, division: "",
            GP: rec.W+rec.L, W: rec.W, L: rec.L,
            Pct: (rec.W+rec.L) ? (rec.W/(rec.W+rec.L)).toFixed(3).replace(/^0/,"") : "-",
            RF: "-", RA: "-", RD: "-"
          }));
        state.franchise.history.push({
          id: uid(),
          seasonNumber: sn,
          completedAt: new Date().toISOString(),
          imported: true,
          champion: S.champion,
          gamesPlayed: standings.reduce((a,r)=>a+r.W,0),
          standings,
          teams: [...S.teams.values()]
        });
        added++;
      }

      state.franchise.history.sort((a,b)=>(a.seasonNumber||0)-(b.seasonNumber||0));
      if(maxSn+1 > state.franchise.seasonNumber) state.franchise.seasonNumber = maxSn+1;

      saveState();
      renderSeasonBadge();
      renderHistory();
      renderRecords();
      let msg = `Imported ${added} season${added===1?"":"s"} (${nBat} batting, ${nPit} pitching, ${nRec} record, ${nChamp} champion rows).`;
      if(skippedSeasons.length) msg += `\nSkipped season number${skippedSeasons.length===1?"":"s"} already in history: ${skippedSeasons.join(", ")}.`;
      if(skippedRows) msg += `\nIgnored ${skippedRows} incomplete row${skippedRows===1?"":"s"}.`;
      msg += `\nCurrent season is now Season ${state.franchise.seasonNumber}.`;
      alert(msg);
    } catch(e){
      alert("Import failed: " + e.message);
    }
  });
}

/*** Records: career stats, single-season records, champions ***/
function normName(n){ return String(n||"").trim().toLowerCase(); }

// Every player-season line across archived history + the current live season
function collectAllSeasonRows(){
  const batRows=[], pitRows=[];
  for(const h of (state.franchise?.history||[])){
    for(const t of (h.teams||[])){
      for(const b of (t.batters||[])){
        const l=b.line||{};
        if(!(Number(l.AB)||Number(l.BB)||Number(l.R))) continue;
        batRows.push({season:h.seasonNumber, team:t.name, name:b.name, pos:b.pos||"", line:l});
      }
      for(const p of (t.pitchers||[])){
        const l=p.line||{};
        if(!(Number(l.OUTS)||Number(l.GP))) continue;
        pitRows.push({season:h.seasonNumber, team:t.name, name:p.name, line:l});
      }
    }
  }
  const sn = state.franchise?.seasonNumber || 1;
  for(const t of state.teams){
    for(const p of (t.roster||[])){
      const s = state.season.batting[p.id];
      if(s && (Number(s.AB)||Number(s.BB)||Number(s.R)))
        batRows.push({season:sn, team:t.name, name:p.name, pos:p.pos||"", line:s, current:true});
    }
    for(const p of (t.pitchers||[])){
      const s = state.season.pitching[p.id];
      if(s && (Number(s.OUTS)||Number(s.GP)))
        pitRows.push({season:sn, team:t.name, name:p.name, line:s, current:true});
    }
  }
  return { batRows, pitRows };
}

const BAT_SUM_KEYS = ["AB","H","2B","3B","HR","RBI","R","BB","SO","SF","MVP"];
const PITCH_SUM_KEYS = ["GP","OUTS","H","R","HR","BB","SO","W","L","SV"];

function careerTotals(){
  const { batRows, pitRows } = collectAllSeasonRows();
  const bat = new Map(), pit = new Map();
  for(const r of batRows){
    const k = normName(r.name);
    if(!bat.has(k)) bat.set(k, { name:r.name, teams:new Set(), seasons:new Set(), line:Object.fromEntries(BAT_SUM_KEYS.map(x=>[x,0])) });
    const c = bat.get(k);
    c.teams.add(r.team); c.seasons.add(r.season);
    for(const key of BAT_SUM_KEYS) c.line[key] += Number(r.line[key])||0;
  }
  for(const r of pitRows){
    const k = normName(r.name);
    if(!pit.has(k)) pit.set(k, { name:r.name, teams:new Set(), seasons:new Set(), line:Object.fromEntries(PITCH_SUM_KEYS.map(x=>[x,0])), ER:0 });
    const c = pit.get(k);
    c.teams.add(r.team); c.seasons.add(r.season);
    for(const key of PITCH_SUM_KEYS) c.line[key] += Number(r.line[key])||0;
    c.ER += getER(r.line);
  }
  return { bat:[...bat.values()], pit:[...pit.values()] };
}

const REC_MIN_AB = 20;     // single-season AVG qualifier
const REC_MIN_OUTS = 30;   // single-season ERA qualifier (10 IP)

function topSeasonList(rows, valueFn, opts={}){
  const { asc=false, min=null, fmt=(v)=>String(v) } = opts;
  const scored = rows
    .filter(r=>!min || min(r))
    .map(r=>({ r, v:valueFn(r) }))
    .filter(x=>Number.isFinite(x.v));
  scored.sort((a,b)=> asc ? (a.v-b.v) : (b.v-a.v));
  return scored.slice(0,10).map(x=>({
    name:x.r.name, team:x.r.team, season:x.r.season, current:!!x.r.current, val:fmt(x.v)
  }));
}

function _recListHtml(title, entries){
  const body = entries.length
    ? entries.map((e,i)=>`<tr><td>${i+1}</td><td>${e.name}</td><td class="small">${e.team}, S${e.season}${e.current?"*":""}</td><td><b>${e.val}</b></td></tr>`).join("")
    : `<tr><td colspan="4" class="small">No data</td></tr>`;
  return `<div class="card" style="background:#0b1229"><h3 style="margin-top:0">${title}</h3><table><tbody>${body}</tbody></table></div>`;
}

function renderChampionsBanner(){
  const elx = el("championsBanner");
  if(!elx) return;
  const hist = (state.franchise?.history||[]).slice().sort((a,b)=>(a.seasonNumber||0)-(b.seasonNumber||0));
  if(!hist.length){
    elx.innerHTML = `<div class="small">No completed seasons yet.</div>`;
    return;
  }
  elx.innerHTML = hist.map(h=>{
    const t = h.champion ? getTeamByName(h.champion) : null;
    const dot = t ? teamDot(t) : "";
    const rec = (h.standings||[]).find(r=>r.name===h.champion);
    const recStr = rec ? ` <span class="small">(${rec.W}-${rec.L})</span>` : "";
    return `<div class="champCard">
      <div class="champSeason">Season ${h.seasonNumber}</div>
      <div class="champName">${h.champion ? `🏆 ${dot}${h.champion}${recStr}` : `<span class="small">No champion recorded</span>`}</div>
    </div>`;
  }).join("");
}

function renderRecords(){
  renderChampionsBanner();

  const { batRows, pitRows } = collectAllSeasonRows();
  const { bat, pit } = careerTotals();

  // ----- Career batting -----
  const cbSort = el("careerBatSort")?.value || "H";
  const cbEl = el("careerBatting");
  if(cbEl){
    const rows = bat.map(c=>{
      const l=c.line, ab=l.AB, h=l.H;
      const avg = ab ? (h/ab) : 0;
      return { c, avg, sortVal: (cbSort==="AVG") ? (ab>=REC_MIN_AB*2 ? avg : -1) : (Number(l[cbSort])||0) };
    });
    rows.sort((a,b)=>b.sortVal-a.sortVal);
    cbEl.innerHTML = _histTable(
      ["Player","Seasons","Teams","AB","H","2B","3B","HR","RBI","R","BB","SO","SF","MVP","AVG"],
      rows.map(({c,avg})=>[
        c.name, c.seasons.size, [...c.teams].join(", "),
        c.line.AB, c.line.H, c.line["2B"], c.line["3B"], c.line.HR, c.line.RBI,
        c.line.R, c.line.BB, c.line.SO, c.line.SF, c.line.MVP,
        avg.toFixed(3).replace(/^0/,"")
      ])
    );
  }

  // ----- Career pitching -----
  const cpSort = el("careerPitchSort")?.value || "W";
  const cpEl = el("careerPitching");
  if(cpEl){
    const rows = pit.map(c=>{
      const outs=c.line.OUTS;
      const era = outs ? (c.ER*9)/(outs/3) : 0;
      let sortVal;
      if(cpSort==="ERA") sortVal = (outs>=REC_MIN_OUTS*2) ? -era : -Infinity; // asc via negation
      else if(cpSort==="IP") sortVal = outs;
      else sortVal = Number(c.line[cpSort])||0;
      return { c, era, sortVal };
    });
    rows.sort((a,b)=>b.sortVal-a.sortVal);
    cpEl.innerHTML = _histTable(
      ["Pitcher","Seasons","Teams","GP","IP","H","R","ER","HR","BB","SO","W","L","SV","ERA"],
      rows.map(({c,era})=>[
        c.name, c.seasons.size, [...c.teams].join(", "),
        c.line.GP, outsToIP(c.line.OUTS), c.line.H, c.line.R, c.ER, c.line.HR,
        c.line.BB, c.line.SO, c.line.W, c.line.L, c.line.SV, era.toFixed(2)
      ])
    );
  }

  // ----- Single-season records -----
  const recEl = el("recordsGrid");
  if(recEl){
    const n = (k)=> (r)=> Number(r.line[k])||0;
    const lists = [
      _recListHtml("HR — Single Season", topSeasonList(batRows, n("HR"))),
      _recListHtml("RBI — Single Season", topSeasonList(batRows, n("RBI"))),
      _recListHtml("Hits — Single Season", topSeasonList(batRows, n("H"))),
      _recListHtml("Runs — Single Season", topSeasonList(batRows, n("R"))),
      _recListHtml(`AVG — Single Season (min ${REC_MIN_AB} AB)`,
        topSeasonList(batRows, r=>{const ab=Number(r.line.AB)||0; return ab?(Number(r.line.H)||0)/ab:NaN;},
          { min:r=>(Number(r.line.AB)||0)>=REC_MIN_AB, fmt:v=>v.toFixed(3).replace(/^0/,"") })),
      _recListHtml("Wins — Single Season", topSeasonList(pitRows, n("W"))),
      _recListHtml("Strikeouts (P) — Single Season", topSeasonList(pitRows, n("SO"))),
      _recListHtml("Saves — Single Season", topSeasonList(pitRows, n("SV"))),
      _recListHtml(`ERA — Single Season (min ${outsToIP(REC_MIN_OUTS)} IP)`,
        topSeasonList(pitRows, r=>{const o=Number(r.line.OUTS)||0; return o?(getER(r.line)*9)/(o/3):NaN;},
          { asc:true, min:r=>(Number(r.line.OUTS)||0)>=REC_MIN_OUTS, fmt:v=>v.toFixed(2) })),
      _recListHtml("IP — Single Season", topSeasonList(pitRows, r=>Number(r.line.OUTS)||0, { fmt:v=>outsToIP(v) })),
      _recListHtml("MVP Points — Single Season", topSeasonList(batRows.filter(r=>(Number(r.line.MVP)||0)>0), r=>Number(r.line.MVP)||0)),
    ];
    recEl.innerHTML = lists.join("");
  }
}

function exportJSON(){
  const blob=new Blob([JSON.stringify(state,null,2)], {type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url; a.download="bhbl_backup.json";
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}
function importJSON(){
  const f=el("importFile").files?.[0];
  if(!f) return alert("Choose a JSON file first.");
  f.text().then(txt=>{
    try {
      const obj=JSON.parse(txt);
      if(!obj.teams) throw new Error("Missing teams");
      if(!obj.franchise) obj.franchise={ seasonNumber:1, history:[] };
      if(obj.season?.batting){
        for(const k of Object.keys(obj.season.batting)){
          if(obj.season.batting[k].SF===undefined) obj.season.batting[k].SF=0;
        }
      }
      state=obj;
      renderSeasonBadge();
      renderHistory();
      saveState();
      renderTeamsAll();
      renderLeague();
      renderSchedule();
      renderStats();
      renderLeaders();
      renderStandings();
      renderAwards();
      renderPlayoffs();
      renderPlay();
      renderPitching();
      alert("Imported!");
    } catch(e) { alert("Import failed: "+e.message); }
  });
}

function showTab(tab){
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active", b.dataset.tab===tab));
  document.querySelectorAll(".panel").forEach(p=>p.classList.toggle("active", p.id===tab));
  if(tab==="league") renderLeague();
  if(tab==="schedule") renderSchedule();
  if(tab==="standings") renderStandings();
  if(tab==="awards") renderAwards();
  if(tab==="playoffs") renderPlayoffs();
  if(tab==="stats") { renderStats(); renderLeaders(); }
  if(tab==="pitching") renderPitching();
  if(tab==="history") renderHistory();
  if(tab==="records") renderRecords();
}
function wireTabs(){ document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click", ()=>showTab(btn.dataset.tab))); }

function creditPitchFromCode(g, code){
  if(g && g.pitcher){
    if(g.pitcher.home) notePitcherEntry("home", g.pitcher.home);
    if(g.pitcher.away) notePitcherEntry("away", g.pitcher.away);
  }
  const pid = currentPitcherId(g);
  if(!pid) return;
  const ps = gamePitch(g, pid);
  const sps = isSeasonGame(g) ? seasonPitch(pid) : null;

  if(code==="BB"){ bump(ps,"BB",1); if(sps) bump(sps,"BB",1); return; }
  if(code==="K"){ bump(ps,"SO",1); bump(ps,"OUTS",1); if(sps){ bump(sps,"SO",1); bump(sps,"OUTS",1); } if(g.decision){ g.decision.pitchOuts[pid]=(g.decision.pitchOuts[pid]||0)+1; } return; }
  if(code.startsWith("FO")){ bump(ps,"OUTS",1); if(sps) bump(sps,"OUTS",1); if(g.decision){ g.decision.pitchOuts[pid]=(g.decision.pitchOuts[pid]||0)+1; } return; }
  if(code.startsWith("GO")){ bump(ps,"OUTS",1); if(sps) bump(sps,"OUTS",1); if(g.decision){ g.decision.pitchOuts[pid]=(g.decision.pitchOuts[pid]||0)+1; } return; }

  // hits
  if(code==="HR"){ bump(ps,"H",1); bump(ps,"HR",1); if(sps){ bump(sps,"H",1); bump(sps,"HR",1); } return; }
  if(code==="3B"){ bump(ps,"H",1); if(sps) bump(sps,"H",1); return; }
  if(code.startsWith("2B")){ bump(ps,"H",1); if(sps) bump(sps,"H",1); return; }
  if(code.startsWith("1B")){ bump(ps,"H",1); if(sps) bump(sps,"H",1); return; }
}

function doRoll(){
  if(!game) return;
  if(game.final) return alert("Game is final. Start a new game or load the next scheduled game.");
  if(game.outs>=3) endHalf(game);

  const bid=batterId(game);
  const batter=getPlayer(bid);
  const roll=roll2d6();
  const code=CHARTS[batter.hr]?.[batter.tier]?.[roll.total];
  triggerPlayFX(code);
  if(!code) { addLog(game, `Rolled ${roll.total} [${roll.d1}+${roll.d2}] but chart missing for tier/hr.`); return; }

  apply(code, roll);
  creditPitchFromCode(game, code);

  if(checkWalkoff(game)){ saveState(); renderPlay(); return; }

  if(game.outs>=3) { addLog(game,"3 outs — half over."); endHalf(game); }
  saveState();
  renderPlay();
}


function simHalf(){
  simFast = true;
  if(!game) return;
  const startHalf=game.half, startIn=game.inning;
  let safety=0;
  while(game.half===startHalf && game.inning===startIn && safety<200){ doRoll(); safety++; }
  simFast = false;
}

function simGame(){
  simFast = true;
  if(!game) return;
  let safety=0;
  while(!game.final && safety<20000){ doRoll(); safety++; }
  addLog(game, "Simulation finished.");
  saveState();
  renderPlay();
  simFast = false;
}



function startSeasonGameFromSchedule(sched){
  const homeId = sched.homeId;
  const awayId = sched.awayId;
  game = newGame(homeId, awayId);
  game.seasonLink = { scheduleId: sched.id, gameNo: sched.gameNo };
  // default pitchers
  game.pitcher.home = getTeam(homeId)?.defaultSPId || "";
  game.pitcher.away = getTeam(awayId)?.defaultSPId || "";
  notePitcherEntry("home", game.pitcher.home);
  notePitcherEntry("away", game.pitcher.away);
  addLog(game, `Season game loaded: Game ${sched.gameNo}.`);
  saveState();
  showTab("play");
  renderPlay();
}

function finalizeSeasonGame(){
  if(!game) return alert("No active game.");
  if(game.seasonLink?.gameType==="playoff") return finalizePlayoffGame();
  if(!isSeasonGame(game)) return alert("This is a Play Mode game (not scheduled). Season stats are not recorded—schedule it first.");
  if(!game.final){
    if(!confirm("Game is not final (may be tied). Finalize anyway?")) return;
  }
  if(!game.seasonLink?.scheduleId) return alert("This game is not linked to the schedule.");
  const sched = state.schedule.find(x=>x.id===game.seasonLink.scheduleId);
  if(!sched) return alert("Scheduled game not found.");
  sched.status = "final";
  sched.awayScore = game.score.away;
  sched.homeScore = game.score.home;
  sched.playedAt = new Date().toISOString();
  sched.innings = game.inning;

  // Save boxscore snapshot for exports
  if(!state.gameHistory) state.gameHistory=[];
  state.gameHistory.push({
    id: uid(),
    gameNo: sched.gameNo,
    awayId: game.awayId,
    homeId: game.homeId,
    awayScore: game.score.away,
    homeScore: game.score.home,
    innings: game.inning,
    playedAt: sched.playedAt,
    box: game.box ? structuredClone(game.box) : {batting:{}, pitching:{}}
  });
  state.gameHistory = state.gameHistory.slice(-500);
  checkLeaderChanges();

  const dec = computePitcherDecisions(game);
  game.decision.finalDecisions = dec;
  applyPitcherDecisionsToSeason(dec);

  // GP (games pitched): count any pitcher who appeared in this game
  const appeared = Object.keys(game.decision?.pitcherEntries || {});
  for(const pid of appeared){
    if(!pid) continue;
    ensurePitch(pid);
    state.season.pitching[pid].GP = Number(state.season.pitching[pid].GP||0) + 1;
  }

  saveState();
  renderTicker();
  renderSchedule();
  renderStandings();
  renderPitching();
  alert(`Finalized: Game ${sched.gameNo} (${getTeam(sched.awayId)?.name||"Away"} ${sched.awayScore} - ${sched.homeScore} ${getTeam(sched.homeId)?.name||"Home"})\nW: ${dec.winPid ? (getPitcher(dec.winner==="home"?game.homeId:game.awayId, dec.winPid)?.name || "?") : "?"}\nL: ${dec.lossPid ? (getPitcher(dec.winner==="home"?game.awayId:game.homeId, dec.lossPid)?.name || "?") : "?"}\nSV: ${dec.savePid ? (getPitcher(dec.winner==="home"?game.homeId:game.awayId, dec.savePid)?.name || "?") : "None"}`);
}

// Schedule sim: simple uses doRoll loop in a temp game
function simulateScheduledGame(gameObj){
  // Sim a scheduled season game using the SAME engine rules as Play mode:
  // - Season stats recorded (seasonLink set)
  // - No ties ever (extras until winner)
  // - Pitching/batting boxscore tracked, decisions applied, GP incremented, gameHistory snapshot saved
  const g = newGame(gameObj.homeId, gameObj.awayId);
  g.seasonLink = { scheduleId: gameObj.id, gameNo: gameObj.gameNo };

  // default pitchers
  g.pitcher.home = getTeam(gameObj.homeId)?.defaultSPId || "";
  g.pitcher.away = getTeam(gameObj.awayId)?.defaultSPId || "";

  // Note pitcher entries (needs global game)
  const _old = game;
  game = g;
  if(g.pitcher.home) notePitcherEntry("home", g.pitcher.home);
  if(g.pitcher.away) notePitcherEntry("away", g.pitcher.away);

  let safety = 0;
  while(!g.final && safety < 50000){
    if(g.outs >= 3){ endHalf(g); safety++; continue; }
    const bid = batterId(g);
    const batter = getPlayer(bid);
    const roll = roll2d6();
    const code = CHARTS[batter.hr]?.[batter.tier]?.[roll.total];
    if(!code){ safety++; continue; }

    apply(code, roll);
    creditPitchFromCode(g, code);

    if(checkWalkoff(g)){ safety++; continue; }

    if(g.outs >= 3) endHalf(g);
    safety++;
  }
  game = _old;

  if(!g.final){
    console.warn("Sim safety stop reached; forcing final.");
    g.final = true;
  }

  // Write back to schedule
  gameObj.status = "final";
  gameObj.homeScore = g.score.home;
  gameObj.awayScore = g.score.away;
  gameObj.playedAt = new Date().toISOString();
  gameObj.innings = g.inning;

  // Save boxscore snapshot for exports/history
  if(!state.gameHistory) state.gameHistory = [];
  state.gameHistory.push({
    id: uid(),
    gameNo: gameObj.gameNo,
    awayId: g.awayId,
    homeId: g.homeId,
    awayScore: g.score.away,
    homeScore: g.score.home,
    innings: g.inning,
    playedAt: gameObj.playedAt,
    box: g.box ? structuredClone(g.box) : { batting:{}, pitching:{} }
  });
  state.gameHistory = state.gameHistory.slice(-500);
  checkLeaderChanges();

  // Decisions + season pitching W/L/SV + GP
  const dec = computePitcherDecisions(g);
  g.decision.finalDecisions = dec;
  applyPitcherDecisionsToSeason(dec);

  const appeared = Object.keys(g.decision?.pitcherEntries || {});
  for(const pid of appeared){
    if(!pid) continue;
    ensurePitch(pid);
    state.season.pitching[pid].GP = Number(state.season.pitching[pid].GP || 0) + 1;
  }

  saveState();
  return { homeScore: g.score.home, awayScore: g.score.away };
}


let peCtx = null; // {kind:"batter"|"pitcher", teamId, id}

function openPlayerEdit(kind, teamId, id){
  const team = getTeam(teamId);
  if(!team) return;
  peCtx = {kind, teamId, id};

  // Populate tier options from main tier select (single source of truth)
  const tierSel = el("peTier");
  if(tierSel){
    tierSel.innerHTML = el("playerTier") ? el("playerTier").innerHTML : tierSel.innerHTML;
  }

  let obj = null;
  if(kind==="batter") obj = (team.roster||[]).find(p=>p.id===id);
  else obj = (team.pitchers||[]).find(p=>p.id===id);
  if(!obj) return;

  el("peTitle").textContent = kind==="batter" ? `Edit Batter — ${team.name}` : `Edit Pitcher — ${team.name}`;
  el("peName").value = obj.name || "";
  el("pePreviewPill").innerHTML = `<b>${obj.name||"Player"}</b>`;
  el("pePreviewHint").textContent = "";

  const batterBox = el("peBatterFields");
  const pitBox = el("pePitcherFields");
  if(kind==="batter"){
    batterBox?.classList.remove("hidden");
    pitBox?.classList.add("hidden");
    el("pePos").value = obj.pos || "";
    if(el("peTier")) el("peTier").value = obj.tier || "C";
    if(el("peHr")) el("peHr").value = obj.hr || "lt20";
    el("pePreviewHint").textContent = `${tierLabel(el("peTier").value)} · ${hrLabel(el("peHr").value)} · (${el("pePos").value||"NA"})`;
  } else {
    batterBox?.classList.add("hidden");
    pitBox?.classList.remove("hidden");
    if(el("peRole")) el("peRole").value = obj.role || "SP";
    el("pePreviewHint").textContent = `Role: ${el("peRole").value}`;
  }

  const modal = el("playerEditModal");
  modal.classList.add("show");
  modal.setAttribute("aria-hidden","false");
}

function closePlayerEdit(){
  const modal = el("playerEditModal");
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden","true");
  peCtx = null;
}

function savePlayerEdit(){
  if(!peCtx) return closePlayerEdit();
  const team = getTeam(peCtx.teamId);
  if(!team) return closePlayerEdit();

  if(peCtx.kind==="batter"){
    const p = (team.roster||[]).find(x=>x.id===peCtx.id);
    if(!p) return closePlayerEdit();
    p.name = el("peName").value.trim() || p.name;
    p.pos = (el("pePos").value.trim() || p.pos || "NA").toUpperCase();
    p.tier = el("peTier").value;
    p.hr = el("peHr").value;
    // ensure season stat objects exist (do not reset)
    if(state.season?.batting) ensureBat(p.id);
    saveState();
    renderRoster();
    renderPlay();
    renderStats();
  } else {
    const p = (team.pitchers||[]).find(x=>x.id===peCtx.id);
    if(!p) return closePlayerEdit();
    p.name = el("peName").value.trim() || p.name;
    p.role = el("peRole").value;
    if(state.season?.pitching) ensurePitch(p.id);
    // if default SP but role changed away from SP, keep id but user can change default SP
    saveState();
    renderPitchers();
    renderPlay();
    renderStats();
  }

  closePlayerEdit();
}

function wirePlayerEditModal(){
  if(el("peClose")) el("peClose").onclick = closePlayerEdit;
  if(el("peSave")) el("peSave").onclick = savePlayerEdit;

  const preview = ()=>{
    if(!peCtx) return;
    const name = el("peName").value.trim() || "Player";
    el("pePreviewPill").innerHTML = `<b>${name}</b>`;
    if(peCtx.kind==="batter"){
      const pos = (el("pePos").value.trim() || "NA").toUpperCase();
      const tier = el("peTier").value;
      const hr = el("peHr").value;
      el("pePreviewHint").textContent = `${tierLabel(tier)} · ${hrLabel(hr)} · (${pos})`;
    } else {
      el("pePreviewHint").textContent = `Role: ${el("peRole").value}`;
    }
  };
  ["peName","pePos","peTier","peHr","peRole"].forEach(id=>{
    if(el(id)) el(id).addEventListener("input", preview);
    if(el(id)) el(id).addEventListener("change", preview);
  });

  // close when clicking backdrop
  const modal = el("playerEditModal");
  if(modal){
    modal.addEventListener("click", (e)=>{
      if(e.target===modal) closePlayerEdit();
    });
  }
}

// Modal

let modalPick = null; // {side:"home|away", kind:"bench|slot", pid, idx}

function clearModalPick(){
  modalPick = null;
  document.querySelectorAll("#modalBenchAwayList li, #modalBenchHomeList li, #modalAwayList li, #modalHomeList li")
    .forEach(li=>li.classList.remove("selected"));
}

function renderModalBenches(){
  const awayBench=el("modalBenchAwayList");
  const homeBench=el("modalBenchHomeList");
  if(!awayBench || !homeBench || !game) return;

  awayBench.innerHTML=""; homeBench.innerHTML="";
  const awayTeam=getTeam(game.awayId);
  const homeTeam=getTeam(game.homeId);

  const awayBenchIds=(awayTeam?.roster||[]).map(p=>p.id).filter(pid=>!game.lineup.away.includes(pid));
  const homeBenchIds=(homeTeam?.roster||[]).map(p=>p.id).filter(pid=>!game.lineup.home.includes(pid));

  const makeItem=(pid)=>{
    const p=getPlayer(pid);
    const li=document.createElement("li");
    li.dataset.pid=pid;
    li.className="listItem";
    li.innerHTML = `<span><b>${p?.name ?? "?"}</b> <span class="small">(${p?.pos ?? "NA"})</span></span>
                    <span class="badge">${tierLabel(p?.tier ?? "")} · ${hrLabel(p?.hr ?? "lt20")}</span>`;
    return li;
  };

  awayBenchIds.forEach(pid=>{ const li=makeItem(pid); awayBench.appendChild(li); awayBench._attachItem(li); });
  homeBenchIds.forEach(pid=>{ const li=makeItem(pid); homeBench.appendChild(li); homeBench._attachItem(li); });

  // click selection handlers
  awayBench._onClickItem = (li)=>{ clearModalPick(); modalPick={side:"away", kind:"bench", pid:li.dataset.pid, idx:null}; li.classList.add("selected"); };
  homeBench._onClickItem = (li)=>{ clearModalPick(); modalPick={side:"home", kind:"bench", pid:li.dataset.pid, idx:null}; li.classList.add("selected"); };

  const awayList=el("modalAwayList");
  const homeList=el("modalHomeList");

  const slotClick = (side, li, idx)=>{
    const pid = li.dataset.pid;
    if(!modalPick){
      clearModalPick();
      modalPick={side, kind:"slot", pid, idx};
      li.classList.add("selected");
      return;
    }
    if(modalPick.side!==side){
      clearModalPick();
      modalPick={side, kind:"slot", pid, idx};
      li.classList.add("selected");
      return;
    }
    if(modalPick.kind==="bench"){
      const benchPid = modalPick.pid;
      const oldPid = game.lineup[side][idx];
      game.lineup[side][idx] = benchPid;
      addLog(game, `${side==="home"?"Home":"Away"} sub: ${getPlayer(benchPid)?.name||"?"} for ${getPlayer(oldPid)?.name||"?"} (slot ${idx+1})`);
      saveState();
      clearModalPick();
      renderModalLineups();
  renderModalBenches();
      renderModalBenches();
      renderPlay();
      return;
    }
    if(modalPick.kind==="slot"){
      const a=modalPick.idx, b=idx;
      const tmp=game.lineup[side][a];
      game.lineup[side][a]=game.lineup[side][b];
      game.lineup[side][b]=tmp;
      addLog(game, `${side==="home"?"Home":"Away"} lineup swap: slot ${a+1} ↔ ${b+1}`);
      saveState();
      clearModalPick();
      renderModalLineups();
  renderModalBenches();
      renderModalBenches();
      renderPlay();
      return;
    }
  };

  if(awayList){
    awayList._onClickItem=(li)=>{
      const items=[...awayList.querySelectorAll("li")];
      const idx=items.indexOf(li);
      slotClick("away", li, idx);
    };
  }
  if(homeList){
    homeList._onClickItem=(li)=>{
      const items=[...homeList.querySelectorAll("li")];
      const idx=items.indexOf(li);
      slotClick("home", li, idx);
    };
  }
}

function openModal(){
  if(!game) return alert("Start a game first.");
  const modal = el("lineupModal");
  modal.classList.add("show");
  modal.setAttribute("aria-hidden","false");
  el("modalAwayName").textContent = `Away: ${getTeam(game.awayId).name}`;
  el("modalHomeName").textContent = `Home: ${getTeam(game.homeId).name}`;
  renderModalLineups();
  renderModalBenches();
}
function closeModal(){
  const modal = el("lineupModal");
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden","true");
}
function renderModalLineups(){
  const awayList=el("modalAwayList");
  const homeList=el("modalHomeList");
  awayList.innerHTML=""; homeList.innerHTML="";
  const makeItem=(pid, idx)=>{
    const p=getPlayer(pid);
    const li=document.createElement("li");
    li.dataset.pid=pid;
    li.innerHTML = `<span>${idx+1}. <b>${p?.name ?? "?"}</b> <span class="small">(${p?.pos ?? "NA"})</span></span>
                    <span class="badge">${tierLabel(p?.tier ?? "")} · ${hrLabel(p?.hr ?? "lt20")}</span>`;
    return li;
  };
  game.lineup.away.forEach((pid,i)=>{ const li=makeItem(pid,i); awayList.appendChild(li); awayList._attachItem(li); });
  game.lineup.home.forEach((pid,i)=>{ const li=makeItem(pid,i); homeList.appendChild(li); homeList._attachItem(li); });
}

// Init
function initDnD(){
  makeDndList(el("lineupList"));
  makeDndList(el("benchList"));
  makeDndList(el("modalAwayList"));
  makeDndList(el("modalHomeList"));
  makeDndList(el("modalBenchAwayList"));
  makeDndList(el("modalBenchHomeList"));
}

function init(){
  if(el("appVersion")) el("appVersion").textContent = "v"+APP_VERSION;
  renderSeasonBadge();
  if(el("startNewSeason")) el("startNewSeason").onclick = startNewSeason;
  if(el("histSeason")) el("histSeason").onchange = renderHistory;
  if(el("histTeam")) el("histTeam").onchange = renderHistory;
  if(el("deleteHistSeason")) el("deleteHistSeason").onclick = deleteHistorySeason;
  if(el("careerBatSort")) el("careerBatSort").onchange = renderRecords;
  if(el("careerPitchSort")) el("careerPitchSort").onchange = renderRecords;
  if(el("downloadHistTemplate")) el("downloadHistTemplate").onclick = downloadHistTemplate;
  if(el("importHistBtn")) el("importHistBtn").onclick = importHistoricalCsv;
  wireTabs();
  renderTeamsAll();
  fillTierSelect(el("playerTier"));
  renderPlayPitcherSelectors();
  initDnD();
  renderPlay();

  el("homeTeam").onchange=renderPlayPitcherSelectors;
  el("awayTeam").onchange=renderPlayPitcherSelectors;

  el("startGame").onclick=()=>{
    // If a game is already loaded and not final, do NOT overwrite it.
    if(game && !game.final){
      // Season game: allow setting pitchers, mark started, then play
      if(isSeasonGame(game)){
        const homeId = game.homeId;
        const awayId = game.awayId;
        const hp = el("homePitcher")?.value || game.pitcher.home || getTeam(homeId)?.defaultSPId || "";
        const ap = el("awayPitcher")?.value || game.pitcher.away || getTeam(awayId)?.defaultSPId || "";
        game.pitcher.home = hp;
        game.pitcher.away = ap;
        notePitcherEntry("home", game.pitcher.home);
        notePitcherEntry("away", game.pitcher.away);
        if(!game.started){
          game.started = true;
          addLog(game,`Season game started: Game ${game.seasonLink?.gameNo ?? ""}.`);
        }
        saveState();
        renderPlay();
        return;
      }

      // Play Mode game already loaded: just continue / update pitchers
      const homeId = game.homeId;
      const awayId = game.awayId;
      game.pitcher.home = el("homePitcher")?.value || game.pitcher.home || "";
      game.pitcher.away = el("awayPitcher")?.value || game.pitcher.away || "";
      notePitcherEntry("home", game.pitcher.home);
      notePitcherEntry("away", game.pitcher.away);
      saveState();
      renderPlay();
      return;
    }

    // Otherwise start a new Play Mode (exhibition) game
    const homeId=el("homeTeam").value;
    const awayId=el("awayTeam").value;
    if(homeId===awayId) return alert("Pick two different teams.");
    game=newGame(homeId, awayId);
    game.pitcher.home = el("homePitcher")?.value || getTeam(homeId)?.defaultSPId || "";
    game.pitcher.away = el("awayPitcher")?.value || getTeam(awayId)?.defaultSPId || "";
    notePitcherEntry("home", game.pitcher.home);
    notePitcherEntry("away", game.pitcher.away);
    addLog(game,`Game started.`);
    saveState();
    renderPlay();
  };
  el("roll").onclick=doRoll;
  el("simHalf").onclick=simHalf;
  el("simGame").onclick=simGame;

  el("editLineup").onclick=openModal;
  if(el("editPitchers")) el("editPitchers").onclick=openPitchModal;
  if(el("closePitchModal")) el("closePitchModal").onclick=closePitchModal;
  if(el("pitchSave")) el("pitchSave").onclick=()=>{
    if(!game) return;
    game.pitcher.away = el("pitchAwaySelect").value || "";
    game.pitcher.home = el("pitchHomeSelect").value || "";
    notePitcherEntry("away", game.pitcher.away);
    notePitcherEntry("home", game.pitcher.home);
    addLog(game, `Pitchers set. Away: ${getPitcher(game.awayId, game.pitcher.away)?.name || "none"} | Home: ${getPitcher(game.homeId, game.pitcher.home)?.name || "none"}`);
    closePitchModal();
    saveState();
    renderPlay();
    renderPitching();
  };
  el("closeModal").onclick=closeModal;
  el("modalSave").onclick=()=>{
    const awayIds = collectListIds(el("modalAwayList")).slice(0,9);
    const homeIds = collectListIds(el("modalHomeList")).slice(0,9);
    if(awayIds.length===9) game.lineup.away = awayIds;
    if(homeIds.length===9) game.lineup.home = homeIds;
    closeModal();
    renderPlay();
  };

  if(el("jumpSchedule")) el("jumpSchedule").onclick=()=>showTab("schedule");
  if(el("jumpLeague")) el("jumpLeague").onclick=()=>showTab("league");

  el("addTeam").onclick=()=>{
    const name=el("newTeam").value.trim();
    if(!name) return;
    state.teams.push({id:uid(),name,roster:[], lineup:[]});
    el("newTeam").value="";
    saveState();
    renderTeamsAll();
    renderLeague();
  };

  el("rosterTeam").onchange=renderRoster;

  el("addPlayer").onclick=()=>{
    const team=getTeam(el("rosterTeam").value);
    if(!team) return;
    const name=el("playerName").value.trim();
    if(!name) return;
    const pos=el("playerPos").value.trim() || "NA";
    const tier=el("playerTier").value;
    const hr=el("playerHr").value;
    const pid=uid();
    team.roster.push({id:pid,name,pos,tier,hr});
    team.lineup = (team.lineup||[]).filter(Boolean);
    if(team.lineup.length<9) team.lineup.push(pid);
    el("playerName").value=""; el("playerPos").value="";
    saveState();
    renderRoster();
    renderLineupEditor();
  };

  el("lineupTeam").onchange=renderLineupEditor;
  if(el("pitRosterTeam")) el("pitRosterTeam").onchange=renderPitchers;
  if(el("defaultSP")) el("defaultSP").onchange=()=>{ const t=getTeam(el("pitRosterTeam").value); if(!t) return; t.defaultSPId = el("defaultSP").value || null; saveState(); renderPlayPitcherSelectors(); };
  if(el("addPitcher")) el("addPitcher").onclick=()=>{ const t=getTeam(el("pitRosterTeam").value); if(!t) return; const name=el("pitcherName").value.trim(); if(!name) return; const role=el("pitcherRole").value; const pid=uid(); t.pitchers.push({id:pid,name,role}); el("pitcherName").value=""; saveState(); renderPitchers(); renderPitching(); renderPlayPitcherSelectors(); };
  el("saveLineup").onclick=()=>{
    const team=getTeam(el("lineupTeam").value);
    if(!team) return;
    const lineupIds = collectListIds(el("lineupList")).slice(0,9);
    const benchIds  = collectListIds(el("benchList"));
    if(lineupIds.length<9) return alert("Lineup must have 9 players. Drag players from bench if needed.");
    setTeamLineup(team, lineupIds, benchIds);
    saveState();
    alert("Saved!");
    renderLineupEditor();
  };

  // schedule
  el("addGame").onclick=()=>{
    const away=el("schedAway").value;
    const home=el("schedHome").value;
    if(away===home) return alert("Pick two different teams.");
    addScheduledGame(away, home);
    renderSchedule();
  };
  
if(el("deleteSelected")) el("deleteSelected").onclick=()=>{
  const g = state.schedule.find(x=>x.id===selectedGameId);
  if(!g) return alert("Click a game row to select it.");
  if(!confirm(`Delete Game ${g.gameNo} (${getTeam(g.awayId)?.name||"Away"} @ ${getTeam(g.homeId)?.name||"Home"})?`)) return;
  state.schedule = state.schedule.filter(x=>x.id!==g.id);
  selectedGameId = null;
  saveState();
  renderSchedule();
  renderStandings();
};

if(el("playSelected")) el("playSelected").onclick=()=>{
  const g = state.schedule.find(x=>x.id===selectedGameId);
  if(!g) return alert("Click a game row to select it.");
  if(g.status==="final") return alert("That game is already final.");
  startSeasonGameFromSchedule(g);
};

if(el("finalizeGame")) el("finalizeGame").onclick=finalizeSeasonGame;

el("simSelected").onclick=()=>{
    const g = state.schedule.find(x=>x.id===selectedGameId);
    if(!g) return alert("Click a game to select it.");
    if(g.status==="final") return alert("That game is already final.");
    const res=simulateScheduledGame(g);
    alert(`Final: ${getTeam(g.awayId).name} ${res.awayScore} — ${getTeam(g.homeId).name} ${res.homeScore}`);
    renderSchedule();
    renderStats();
  };
  el("simAll").onclick=()=>{
    let count=0;
    for(const g of state.schedule){
      if(g.status!=="final"){ simulateScheduledGame(g); count++; }
    }
    alert(`Simulated ${count} game(s).`);
    renderSchedule();
    renderStats();
  };

  // stats
  el("statsTeam").onchange=renderStats;
  if(el("leadBatCat")) el("leadBatCat").onchange=renderLeaders;
  if(el("leadPitCat")) el("leadPitCat").onchange=renderLeaders;
  if(el("leadTopN")) el("leadTopN").onchange=renderLeaders;
  if(el("poLeadType")) el("poLeadType").onchange=renderPlayoffLeaders;
  if(el("poLeadCat")) el("poLeadCat").onchange=renderPlayoffLeaders;
  if(el("pitchTeam")) el("pitchTeam").onchange=renderPitching;
  if(el("recalcStandings")) el("recalcStandings").onclick=renderStandings;
  if(el("standingsView")) el("standingsView").onchange=renderStandings;

  if(el("addDivision")) el("addDivision").onclick=()=>{
    ensureDivisions();
    const name = (el("newDivisionName")?.value || "").trim();
    if(!name) return alert("Enter a division name.");
    state.season.structure.divisions.push({id:uid(), name});
    el("newDivisionName").value="";
    // Assign any unassigned teams
    ensureDivisions();
    saveState();
    renderStandings();
  };

  if(el("recalcAwards")) el("recalcAwards").onclick=renderAwards;
  el("resetStats").onclick=()=>{
    if(!confirm("Reset ALL season stats AND mark scheduled games unplayed?")) return;
    const structure = state.season?.structure ? JSON.parse(JSON.stringify(state.season.structure)) : { leagueName:"League", divisions:[] };
    state.season={batting:{}, pitching:{}, standings:{}, gameLog:[], structure, playoffs:null, playoffStats:{batting:{}, pitching:{}}};
    for(const g of state.schedule){ g.status="scheduled"; g.homeScore=0; g.awayScore=0; g.playedAt=null; }
    saveState();
    renderStats();
    renderSchedule();
    renderStandings();
    renderAwards();
    renderPlayoffs();
  };

  el("exportJson").onclick=exportJSON;
  el("importJson").onclick=importJSON;


  // Schedule generator
  if(el("genSchedule")) el("genSchedule").onclick=generateSchedule;
  if(el("clearSchedule")) el("clearSchedule").onclick=clearScheduleAll;
  if(el("genPlayoffs")) el("genPlayoffs").onclick=generatePlayoffs;
  if(el("resetPlayoffs")) el("resetPlayoffs").onclick=resetPlayoffs;

  // Exports
  if(el("exportSeasonCsv")) el("exportSeasonCsv").onclick=exportSeasonCsv;
  if(el("exportScheduleCsv")) el("exportScheduleCsv").onclick=exportScheduleCsv;
  if(el("exportBoxscoresCsv")) el("exportBoxscoresCsv").onclick=exportBoxscoresCsv;
  if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
}

window.addEventListener("DOMContentLoaded", init);
function downloadText(filename, text){
  const blob = new Blob([text], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 250);
}
function toCsv(rows){
  const esc = (v)=>{
    if(v===null || v===undefined) return "";
    const s = String(v);
    if(/[",\n]/.test(s)) return '"' + s.replace(/"/g,'""') + '"';
    return s;
  };
  return rows.map(r=>r.map(esc).join(",")).join("\n");
}

function teamOfPlayer(pid){
  for(const t of state.teams){
    if(t.roster?.some(p=>p.id===pid)) return t;
  }
  return null;
}

function pushTicker(msg){
  if(!msg) return;
  if(!state.ticker) state.ticker={queue:[], last:{HR:null}};
  state.ticker.queue = state.ticker.queue || [];
  state.ticker.queue.unshift({ msg, ts: Date.now() });
  state.ticker.queue = state.ticker.queue.slice(0, 20);
  saveState();
  renderTicker();
}
function renderTicker(){
  const bar = el("ticker");
  if(!bar) return;
  const q = state.ticker?.queue || [];
  if(q.length===0){
    bar.classList.add("hidden");
    return;
  }
  bar.classList.remove("hidden");
  el("tickerMsg").textContent = q[0].msg;
}

function computeLeaderHR(){
  let bestPid=null, bestVal=-1;
  for(const pid in state.season.batting){
    const s = state.season.batting[pid];
    const v = Number(s.HR||0);
    if(v>bestVal){ bestVal=v; bestPid=pid; }
  }
  return {pid:bestPid, val: bestVal<0?0:bestVal};
}

function checkLeaderChanges(){
  const hr = computeLeaderHR();
  const last = state.ticker?.last?.HR;
  if(!last || last.pid!==hr.pid || last.val!==hr.val){
    state.ticker.last.HR = hr;
    if(hr.pid){
      const p = getPlayer(hr.pid);
      const t = teamOfPlayer(hr.pid);
      const teamName = t?.name ? ` (${t.name})` : "";
      pushTicker(`New HR leader: ${p?.name||"Unknown"}${teamName} (${hr.val})`);
    }
  }
}

/* Exports */
function exportSeasonCsv(){
  const rows=[];
  rows.push(["Type","Player","Team","AB","H","HR","RBI","R","BB","SO","2B","3B","SF","AVG"]);
  for(const t of state.teams){
    for(const p of (t.roster||[])){
      const s = state.season.batting[p.id] || { AB:0,H:0,HR:0,RBI:0,R:0,BB:0,SO:0,"2B":0,"3B":0 };
      const avg = s.AB ? (s.H/s.AB) : 0;
      rows.push(["Batting",p.name,t.name,s.AB,s.H,s.HR,s.RBI,s.R,s.BB,s.SO,s["2B"]||0,s["3B"]||0,s.SF||0,avg.toFixed(3)]);
    }
  }
  rows.push([]);
  rows.push(["Type","Pitcher","Team","GP","IP","OUTS","H","R","ER","HR","BB","SO","W","L","SV","ERA"]);
  for(const t of state.teams){
    for(const p of (t.pitchers||[])){
      const s = state.season.pitching[p.id] || { OUTS:0,H:0,R:0,ER:0,HR:0,BB:0,SO:0,W:0,L:0,SV:0 };
      const ip = outsToIP(s.OUTS||0);
      const era = s.OUTS ? (((s.ER||0)*9)/(s.OUTS/3)) : 0;
      rows.push(["Pitching",p.name,t.name,(s.GP||0),ip,s.OUTS||0,s.H||0,s.R||0,(s.ER||0),s.HR||0,s.BB||0,s.SO||0,s.W||0,s.L||0,s.SV||0,era.toFixed(2)]);
    }
  }
  downloadText("BHBL_Season_Stats.csv", toCsv(rows));
}

function exportScheduleCsv(){
  const rows=[["GameNo","Away","Home","Status","AwayScore","HomeScore","PlayedAt"]];
  const byId = Object.fromEntries(state.teams.map(t=>[t.id,t.name]));
  for(const g of state.schedule){
    rows.push([g.gameNo, byId[g.awayId]||"", byId[g.homeId]||"", g.status||"", g.awayScore??"", g.homeScore??"", g.playedAt||""]);
  }
  downloadText("BHBL_Schedule.csv", toCsv(rows));
}

function exportBoxscoresCsv(){
  const rows=[];
  const byId = Object.fromEntries(state.teams.map(t=>[t.id,t.name]));
  rows.push(["GameNo","Away","Home","AwayScore","HomeScore","Section","Player","Team","AB","H","HR","RBI","R","BB","SO","2B","3B","SF","IP","OUTS","PH","PR","PER","PHR","PBB","PSO"]);
  for(const g of (state.gameHistory||[])){
    const away = byId[g.awayId]||"";
    const home = byId[g.homeId]||"";
    for(const pid in (g.box?.batting||{})){
      const p=getPlayer(pid);
      const team=teamOfPlayer(pid)?.name||"";
      const s=g.box.batting[pid];
      rows.push([g.gameNo||"",away,home,g.awayScore,g.homeScore,"Batting",p?.name||"",team,s.AB||0,s.H||0,s.HR||0,s.RBI||0,s.R||0,s.BB||0,s.SO||0,s["2B"]||0,s["3B"]||0,s.SF||0,"","","","","","",""]);
    }
    for(const pid in (g.box?.pitching||{})){
      const team = (getTeam(g.homeId)?.pitchers||[]).some(x=>x.id===pid) ? (byId[g.homeId]||"") :
                   (getTeam(g.awayId)?.pitchers||[]).some(x=>x.id===pid) ? (byId[g.awayId]||"") : "";
      const s=g.box.pitching[pid];
      const name = getPitcher(g.homeId,pid)?.name || getPitcher(g.awayId,pid)?.name || getPlayer(pid)?.name || "";
      rows.push([g.gameNo||"",away,home,g.awayScore,g.homeScore,"Pitching",name,team,"","","","","","","","","","",outsToIP(s.OUTS||0),s.OUTS||0,s.H||0,s.R||0,(s.ER||0),s.HR||0,s.BB||0,s.SO||0]);
    }
  }
  downloadText("BHBL_Boxscores.csv", toCsv(rows));
}


window.onerror = function(message, source, lineno, colno, error){
  try{
    console.error("BHBL Error:", message, source, lineno, colno, error);
    if(typeof pushTicker==="function"){
      pushTicker("App error: " + message + " (see console)");
    } else {
      alert("App error: " + message);
    }
  }catch(e){}
  return false;
};


